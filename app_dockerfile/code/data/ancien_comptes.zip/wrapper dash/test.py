# CALENDRIER
# from datetime import datetime as dt
# import dash
# import dash_html_components as html
# import dash_core_components as dcc
# import re

# external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

# app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
# app.layout = html.Div([
#     dcc.DatePickerRange(
#         id='my-date-picker-range',
#         min_date_allowed=dt(1995, 8, 5),
#         max_date_allowed=dt(2020, 9, 19),
#         initial_visible_month=dt(2017, 8, 5),
#         end_date=dt(2017, 8, 25).date()
#     ),
#     html.Div(id='output-container-date-picker-range')
# ])


# @app.callback(
#     dash.dependencies.Output('output-container-date-picker-range', 'children'),
#     [dash.dependencies.Input('my-date-picker-range', 'start_date'),
#      dash.dependencies.Input('my-date-picker-range', 'end_date')])
# def update_output(start_date, end_date):
#     string_prefix = 'You have selected: '
#     if start_date is not None:
#         start_date = dt.strptime(re.split('T| ', start_date)[0], '%Y-%m-%d')
#         start_date_string = start_date.strftime('%B %d, %Y')
#         string_prefix = string_prefix + 'Start Date: ' + start_date_string + ' | '
#     if end_date is not None:
#         end_date = dt.strptime(re.split('T| ', end_date)[0], '%Y-%m-%d')
#         end_date_string = end_date.strftime('%B %d, %Y')
#         string_prefix = string_prefix + 'End Date: ' + end_date_string
#     if len(string_prefix) == len('You have selected: '):
#         return 'Select a date to see it displayed here'
#     else:
#         return string_prefix


# if __name__ == '__main__':
#     app.run_server(debug=True)
    
    
from datetime import datetime as dt
import dash
import dash_html_components as html
import dash_core_components as dcc
import re

import plotly.express as px

# depensesSemaines_titre = html.H2(children="Dépenses de la semaine")
# dedpensesSemaines_graph = dcc.Graph(id="despenses_semaine_graph",
#                                     figure={"data":[{"x":[1,2,3,5], "y":[1,2,3,5], "name":"Dépenses semaine"}]})
# depensesSemaines_DIV = html.Div(children=[depensesSemaines_titre, dedpensesSemaines_graph])

# depensesMoiss_titre = html.H2(children="Dépenses de le mois")
# dedpensesMoiss_graph = dcc.Graph(id="despenses_mois_graph",
#                                     figure={"data":[{"x":[1,2,3,5], "y":[1,2,3,5], "name":"Dépenses mois"}]})
# depensesMois_DIV = html.Div(children=[depensesMoiss_titre, dedpensesMoiss_graph])

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


class InputDiv():
    def __init__(self):
        
        self.periode_input = dcc.RadioItems(
            options=[
                {"label":"Semaine", "value":"week"},
                {"label":"Mois", "value":"month"},
                {"label":"Trimestre", "value":"semestre"}
            ],
            value='month'
        )

        self.date_input = dcc.DatePickerSingle(
            id='date-picker-single',
            date=dt.now(),
            display_format="D/M/Y"
        )

    def getDiv(self):
        div_input = html.Div(children=[self.date_input, self.periode_input])
        return div_input
        
my_input = InputDiv()  


# Load data



df = px.data.iris() # iris is a pandas DataFrame
fig = px.scatter(df, x="sepal_width", y="sepal_length")

print(df)

data = [
    dict(
        x=df[df["species"] == i]["sepal_length"],
        y=df[df["species"] == i]["sepal_width"],
        name=i) for i in df.species.unique()
]

graphique = dcc.Graph(figure={"data":data})

app.layout = html.Div([
    my_input.getDiv(),
    graphique
])


if __name__ == '__main__':
    app.run_server(debug=True)
