import pymysql

import datetime
from dateutil.relativedelta import relativedelta

import pandas as pd
import numpy as np

from utility_fct import *


class SQLConnector():
    def __init__(self):
        self.hostname = 'localhost'
        self.username = 'root'
        self.password = ''
        self.database = 'depenses'
        
        self.myConnection, self.cursor = self.connect()
        
    def connect(self):
        myConnection = pymysql.connect( host=self.hostname,
                                       user=self.username,
                                       passwd=self.password,
                                       db=self.database )
        return myConnection, myConnection.cursor()
    
    def  end_connection(self):
        self.myConnection.close()



class SQLWrapper(SQLConnector):
    def __init__(self):
        super().__init__()
        
    def execute_select(self, request_sql):
        print(request_sql)
        self.execute(request_sql)
        return self.cursor.fetchall()
        
    def execute(self, request_sql):
        response = self.cursor.execute(request_sql)
        return response




class SQLWrapperForDate(SQLWrapper):
    def __init__(self):
        super().__init__()
    
    def getDataframeFromDate(self, start_date, periode):
        end_date = self.getEndDate(start_date, periode)
        response_sql = self.getDataFromDateToDate(start_date, end_date)
        #Convert the response into a pandas DataFrame
        data_frame = pd.DataFrame(list(response_sql))
        if data_frame.empty:
            return data_frame
        #Change the columns names to coïncide with the sql table
        columns_name = self.getColumnsName()
        data_frame.columns = columns_name
        #Get Only One theme in the theme column
        data_frame = self.cleanTheme(data_frame)
        self._df = data_frame        
        return data_frame
    
    def getEndDate(self, start_date, periode):
        end_date = start_date        
        if periode == "week":
            end_date += relativedelta(weeks=1)
        elif periode == "month":
            end_date += relativedelta(months=1)
        elif periode == "semestre":
            end_date += relativedelta(months=4)
        return end_date
        
    def getDataFromDateToDate(self, start_date, end_date):
        reponse = self.execute_select("SELECT * FROM depenses_brutes WHERE date >= "
                                      +self.getGoodDatetimeShape(start_date)+" AND date < "
                                      +self.getGoodDatetimeShape(end_date))
        return reponse

    def getGoodDatetimeShape(self, my_datetime):
        return "'"+my_datetime.strftime("%Y-%m-%d")+"'"
    
    def getColumnsName(self):
        request = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='depenses' AND TABLE_NAME='depenses_brutes'"
        reponse = self.execute_select(request)
        list_columns = []
        for column in reponse:
            list_columns.append(column[0])
        return list_columns
    
    def cleanTheme(self, df):
        df["theme"] = df["theme"].apply(convertStrIntoThemeSubThemes)
        return df
        
    
    def getDataframeOfFoodFromDate(self, start_date, periode):
        end_date = self.getEndDate(start_date, periode)
        response_sql = self.getDataFromDateToDate(start_date, end_date)
        #Convert the response into a pandas DataFrame
        data_frame = pd.DataFrame(list(response_sql))
        if data_frame.empty:
            return data_frame
        #Change the columns names to coïncide with the sql table
        columns_name = self.getColumnsName()
        data_frame.columns = columns_name
        #Get Only One theme in the theme colum and one subtheme
        data_frame = self.cleanThemeGetSubtheme(data_frame)
        self._df = data_frame        
        return data_frame
        
    def cleanThemeGetSubtheme(self, df):
        df = df[df.theme.str.contains("^alimentaire", regex=True, na=False)]
        df["subtheme"] = df["theme"].apply(convertStrIntoSubThemes)
        return df
        


class OperationsSQL(SQLWrapperForDate):
    def __init__(self):
        super().__init__()
        
    def getDictOfExpensesByThemeFromDate(self, start_date, periode="month"):
        data = self.getDataframeFromDate(start_date, periode)
        if data.empty:
            return []
        expenses_to_graph = self.getDataframeToGraph(data, "scatter")
        return expenses_to_graph
        
    def getDictOfExpensesOfFoodFromDate(self, start_date, periode="month"):
        end_date = self.getEndDate(start_date, periode)
        current_date = start_date
        dict_prep_expenses = {}
        while current_date < end_date:
            data = self.getDataframeOfFoodFromDate(current_date, "week")
            if data.empty:
                dict_expenses_week = {}
            else:
                unique_subtheme = data["subtheme"].unique()
                dict_expenses_week = {i:dict(
                        x = [current_date],
                        y = [np.sum(data[data["subtheme"] == i]["montant"])],
                        name = i
                    ) for i in unique_subtheme}
            dict_prep_expenses = update_dict_with_lists(dict_prep_expenses, dict_expenses_week)
            current_date += relativedelta(weeks=1)
        expenses_to_graph = list(dict_prep_expenses.values())
        return expenses_to_graph
        
    def getDictOfExpensesByThemeByWeekFromDate(self, start_date, periode):
        end_date = self.getEndDate(start_date, periode)
        current_date = start_date
        dict_prep_expenses = {}
        nbr_weeks = 0
        while current_date < end_date:
            nbr_weeks += 1
            data = self.getDataframeFromDate(current_date, "week")
            if data.empty:
                dict_expenses_week = {}
            else:
                unique_theme = data["theme"].unique()
                dict_expenses_week = {i:dict(
                        x = [current_date],
                        y = [np.sum(data[data["theme"] == i]["montant"])],
                        name = i
                    ) for i in unique_theme}
            temp_dict = dict(dict_prep_expenses)
            dict_prep_expenses = update_dict_with_lists(dict_prep_expenses, dict_expenses_week)
            if temp_dict == dict_prep_expenses:
                print("ICI : ", nbr_weeks)
            current_date += relativedelta(weeks=1)
        
        expenses_to_graph = list(dict_prep_expenses.values())
        return expenses_to_graph
    
    def getDataframeToGraph(self, data, type_graph):
        if type_graph == "scatter":
            unique_theme = data["theme"].unique()
            list_prep_expenses = [dict(
                    x=data[data["theme"] == i]["date"],
                    y=data[data["theme"] == i]["montant"],
                    text=data[data["theme"] == i]["description"],
                    name = i
                ) for i in unique_theme]
            return list_prep_expenses
        
        if type_graph == "alim-bar":
            unique_theme = data["subtheme"].unique()
            list_prep_expenses = [dict(
                    x=data[data["subtheme"] == i]["date"],
                    y=data[data["subtheme"] == i]["montant"],
                    text=data[data["subtheme"] == i]["description"],
                    name = i
                ) for i in unique_theme]
            return list_prep_expenses


if __name__ == "__main__":
    start_date = datetime.datetime(2020,1,1)
    # end_date = datetime.datetime(2020,1,10)
    
    myOperator = OperationsSQL()
    result = myOperator.getDictOfExpensesByThemeFromDate(start_date)
    
    print(result)