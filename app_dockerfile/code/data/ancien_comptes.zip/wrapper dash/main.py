from dash_display import *

# from datetime import datetime as dt



# # --- Initialisations ---
# input_div = InputDiv()  

# # -- UPPER DASHBOARD -- 
# my_input = input_div.getDiv()
# graph_data = GraphFig()
# scatter_graph = graph_data.getEmptyGraph("scatter")
# upper_dashboard = html.Div([my_input, scatter_graph],
#                             style= {'display': 'block'})

# # -- BOTTOM DASHBOARD -- 
# pie_graph = graph_data.getEmptyGraph("pie")
# mean_graph = graph_data.getEmptyGraph("mean")
# bottom_dashboard = html.Div([mean_graph, pie_graph],
#                             style= {'display': 'flex'})

# # -- SETTING APP SPECIFICATIONS --
# app.layout = html.Div([
#     upper_dashboard,
#     bottom_dashboard,
# ])

myDashboard = Dashboard()

# -- RUNNING APP --
myDashboard.run()


