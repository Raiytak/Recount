import sql_wrapper
from utility_fct import *

import dash
import dash_html_components as html
import dash_core_components as dcc

import datetime
from datetime import datetime as dt
from dateutil.relativedelta import relativedelta

import numpy as np

app = dash.Dash()

GLOBAL_DATE = dt.now()

class InputDiv():
    def __init__(self):
        
        self.periode_input = dcc.RadioItems(
            id="input-radio",
            options=[
                {"label":"Semaine", "value":"week"},
                {"label":"Mois", "value":"month"},
                {"label":"Trimestre", "value":"semestre"}
            ],
            value='month'
        )

        self.date_input = dcc.DatePickerSingle(
            id="input-date",
            date = dt.now()-relativedelta(months=4),
            display_format="D/M/Y"
        )

    def getDiv(self):
        div_input = html.Div(children=[self.date_input,
                                       self.periode_input,])
        return div_input
        

# Load data
class GraphData():
    def __init__(self):
        self._myOperator = sql_wrapper.OperationsSQL()
        
    def getScatterDict(self, expenses_to_graph):
        list_data = []
        #Adding specifications to data
        for row in expenses_to_graph:
            row["mode"] = "markers"
            list_data.append(row)
        fig_data = {"data":list_data,
                    "layout":{"title":{"text":"Dépenses par thème"},
                              "yaxis": {"type": "log", "title":"Dépenses (euros)"},
                              "xaxis":{"title":"Jour"}}
        }
        return fig_data
    
    def getPieDict(self, expenses_to_graph):
        list_data = {"values":[], "names":[], "labels":[], "type":"pie"}
        #Changing global data to sum
        for row in expenses_to_graph:
            list_data["values"].append(sum(row["y"]))
            list_data["names"].append(row["name"])
            list_data["labels"].append(row["name"])
        list_data = [list_data]
        fig_data = {"data":list_data,
                    "layout":{"title":{"text":"Camembert des thèmes"}}
        }
        return fig_data
    
    def getMeanDict(self, expenses_to_graph):
        list_data = []
        #Adding specifications to data
        for row in expenses_to_graph:
            row["type"] = "bar"
            # row["barmode"] = "stack"
            list_data.append(row)
        fig_data = {"data":list_data,
                    "layout":{"title":{"text":"Total des dépenses par semaine"},
                              "barmode":"stack",
                              "yaxis": {"title":"Dépenses (euros)"},
                              "xaxis":{"title":"Jour"}}
        }
        return fig_data
    
    def getFoodDict(self, expenses_to_graph):
        list_data = []
        #Adding specifications to data
        for row in expenses_to_graph:
            row["type"] = "bar"
            list_data.append(row)
        fig_data = {"data":list_data,
                    "layout":{"title":{"text":"Dépenses par semaine en nourriture"},
                              "barmode":"stack",
                              "yaxis": {"title":"Dépenses (euros)"},
                              "xaxis":{"title":"Jour"}}
        }
        return fig_data
    
    
    
class GraphFig(GraphData):
    def __init__(self):
        super().__init__()
        
    def getEmptyGraph(self, graph_type):
        if graph_type=="scatter":
            return dcc.Graph(id="scatter-output")
        if graph_type=="pie":
            return dcc.Graph(id="pie-output")
        if graph_type=="mean":
            return dcc.Graph(id="mean-output")
        if graph_type=="food":
            return dcc.Graph(id="food-output")
        
     
    def getScatterGraph(self, start_date, periode):
        list_prep_data = self.getDataframeFromDate(start_date, periode)
        fig_data = self.getScatterDict(list_prep_data)
        return fig_data     
    
    def getPieGraph(self, start_date, periode):
        list_prep_data = self.getDataframeFromDate(start_date, periode)
        fig_data = self.getPieDict(list_prep_data)
        return fig_data
    
    def getMeanGraph(self, start_date, periode):
        list_prep_data = self.getDataFromDateByWeek(start_date, periode)
        fig_data = self.getMeanDict(list_prep_data)
        return fig_data
    
    def getFoodGraph(self, start_date, periode):
        list_prep_data = self.getDataFoodFromDateByWeek(start_date, periode)
        fig_data = self.getFoodDict(list_prep_data)
        return fig_data
    
    def getDataframeFromDate(self, start_date, periode):
        return self._myOperator.getDictOfExpensesByThemeFromDate(start_date, periode)

    def getDataFromDateByWeek(self, start_date, periode):
        return self._myOperator.getDictOfExpensesByThemeByWeekFromDate(start_date, periode)  

    def getDataFoodFromDateByWeek(self, start_date, periode):
        return self._myOperator.getDictOfExpensesOfFoodFromDate(start_date, periode)  


@app.callback(
    [dash.dependencies.Output("scatter-output", "figure"),
    dash.dependencies.Output("pie-output", "figure"),
    dash.dependencies.Output("mean-output", "figure"),
    dash.dependencies.Output("food-output", "figure")],
    [dash.dependencies.Input("input-date", 'date'),
     dash.dependencies.Input("input-radio", 'value')])
def update_graph(selected_date_str, selected_periode):
    selected_date = getDate(selected_date_str)
    newGraph = GraphFig()    
    scatter_graph = newGraph.getScatterGraph(selected_date, selected_periode)
    pie_graph = newGraph.getPieGraph(selected_date, selected_periode)
    mean_graph = newGraph.getMeanGraph(selected_date, selected_periode)
    food_graph = newGraph.getFoodGraph(selected_date, selected_periode)
    
    return scatter_graph, pie_graph, mean_graph, food_graph



class Dashboard():
    def __init__(self):
        pass
    
    def run(self):
        input_div = InputDiv()  
        my_input = input_div.getDiv()
        
        graph_data = GraphFig()
        scatter_graph = graph_data.getEmptyGraph("scatter")
        pie_graph = graph_data.getEmptyGraph("pie")
        upper_board = html.Div([scatter_graph, pie_graph],
                                    style= {'display': 'flex'})
        upper_dashboard = html.Div([my_input, upper_board],
                                    style= {'display': 'block'})
        
        
        
        mean_graph = graph_data.getEmptyGraph("mean")
        food_graph = graph_data.getEmptyGraph("food")
        bottom_dashboard = html.Div([mean_graph, food_graph],
                                    style= {'display': 'flex'})
        
        app.layout = html.Div([
            upper_dashboard,
            bottom_dashboard,
        ])
        
        app.run_server(debug=True)
        


if __name__ == '__main__':
    myDashboard = Dashboard()
    myDashboard.run()