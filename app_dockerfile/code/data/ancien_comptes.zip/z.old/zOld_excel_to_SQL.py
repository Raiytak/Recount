
    
    

from basic_analyser import BasicExcelAnalyser
import os
import sys

if __name__ == "__main__":
    basicExcelAnalyser = BasicExcelAnalyser()
    myTransfert = csvTOsql(basicExcelAnalyser)
    
    start_datetime = datetime.datetime(2019,8,1)
    end_datetime = datetime.datetime.now()
    end_datetime = datetime.datetime(2019,8,30)
    
    # myTransfert.insertDate(start_datetime, end_datetime)
    myTransfert.insertExcel()
    # myTransfert.dump_db_table()
    

    myTransfert.end_connection()

    

class BasicExcelAnalyser():
    
    """ -------------------- ANCIEN -------------------- """
    def listeTuplesIndiceDateExpressionPrixDansExcel(self, regex_expression, datetime_debut = "debut", datetime_fin = "fin"):
        indice_debut = self.convertiDatetimeOuStringEnIndice(datetime_debut)
        indice_fin = self.convertiDatetimeOuStringEnIndice(datetime_fin)
        liste_indice_date_quoi_prix_a_retourner = []
        for i in range(indice_debut, indice_fin):
            if regex_expression in self.valeurStringDansExcel("Quoi",i):
                liste_indice_date_quoi_prix_a_retourner.append(self.appendIndiceDateQuoiPrixDeLaLigne(i))
        return liste_indice_date_quoi_prix_a_retourner
    
    def appendIndiceDateQuoiPrixDeLaLigne(self, indice):
        datetime_type = self.dateExcelOfRowIndice(indice)
        date_europ_type = self.dateAuFormatEuropeen(datetime_type)
        quoi_excel = self.valeurStringDansExcel("Quoi",indice)
        prix_euros_excel = self.valeurNombreDansExcel("Dépenses Euros",indice)
        prix_dollars_excel = self.valeurNombreDansExcel("Dépenses Dollars",indice)
        liste_prix = [prix_euros_excel, prix_dollars_excel]
        return (indice, date_europ_type, quoi_excel, liste_prix)
        
    def convertiDatetimeOuStringEnIndice(self, element_a_convertir):
        if type(element_a_convertir) == str:
            return self.convertiStringEnIndice(element_a_convertir)
        elif type(element_a_convertir) == datetime.datetime:
            return self.indiceExcelStartOfDatetime(element_a_convertir)
        return element_a_convertir
    
    def convertiStringEnIndice(self, indice_a_initialiser):
        if indice_a_initialiser == "debut":
            return self.indice_start_excel
        elif indice_a_initialiser == "fin":
            return self.indice_end_excel
        return indice_a_initialiser #RAISE EXCEPTION
        
    def convertionEnEurosDeLaListe(self, liste_a_convertir):
        if liste_a_convertir == []:
            return []
        indice_de_la_liste_euro_dollar = self.indiceDeLaListeEuroDollar(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            depense_en_euros = self.conversionEnEurosDe(une_ligne_de_la_liste_a_convertir[indice_de_la_liste_euro_dollar])
            liste_brute[indice_de_la_liste_euro_dollar] = depense_en_euros
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
            
    def indiceDeLaListeEuroDollar(self, liste_a_convertir):
        indice_liste_euro_dollar = 0
        for element_ligne in liste_a_convertir[0]:
            if (type(element_ligne) == tuple) or (type(element_ligne) == list):
                return indice_liste_euro_dollar
            indice_liste_euro_dollar += 1
        print("Liste euro dollar non trouvée dans la liste : ", liste_a_convertir)
        return -1
    
    def conversionEnEurosDe(self, liste_euro_dollar):
        depense_euros = liste_euro_dollar[0]
        depense_dollars_converti_en_euros = liste_euro_dollar[1]*self.taux_de_change_dollarC_euro
        return depense_euros + depense_dollars_converti_en_euros
    
    def convertionDeDateEnDatetimeDeLaListe(self, liste_a_convertir): 
        indice_de_la_date = self.indiceDeLaDate(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            datetime_de_la_date = self.conversionStrDateIntoDatetime(une_ligne_de_la_liste_a_convertir[indice_de_la_date])
            liste_brute[indice_de_la_date] = datetime_de_la_date
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
    
    def indiceDeLaDate(self, liste_a_convertir):
        if liste_a_convertir == []:
            return []
        indice_date = 0
        for element_ligne in liste_a_convertir[0]:
            if (type(element_ligne) == str) and (type(int(element_ligne[0])) == int):
                return indice_date
            indice_date += 1
        print("Date non trouvée dans la liste : ", liste_a_convertir)
        return -1    
    
    def listeDatePrixDuTheme(self, theme="", datetime_debut = "debut", datetime_fin = "fin"):
        list_date,list_prix = [],[]
        list_indices = self.trouveIndicesDuTheme(theme, datetime_debut, datetime_fin)
        for indice in list_indices:
            date_indice = self.dateExcelOfRowIndice(indice)
            list_date.append(date_indice)
            prix_indice = self.prixEuroDeLaLigne(indice)
            list_prix.append(prix_indice)
        return [list_date, list_prix]
    
    def trouveIndicesDuTheme(self, theme="", datetime_debut = "debut", datetime_fin = "fin"):
        list_indices = []
        theme_abreviation = self.retourneAbreviationDuTheme(theme)
        for i in range(self.len_excel):
            if theme_abreviation in self.excel_credit_etudiant["Thème"]:
                list_indices.append(i)
        return list_indices
    
    def retourneAbreviationDuTheme(self, theme):
        if theme == "courses":
            return "c:"
    
    def prixEuroDeLaLigne(self, indice):
        prix_euros = self.excel_credit_etudiant["Dépenses Euros"][indice]
        prix_dollars = self.excel_credit_etudiant["Dépenses Dollars"][indice]
        list_euros_dollars = [prix_euros, prix_dollars]
        prix_euros_total = self.conversionEnEurosDe(list_euros_dollars)
        return prix_euros_total
    
    
    




def pop_end(name_directory):
    size = len(name_directory)
    for i in range(size-1,0,-1):
        if name_directory[i] == "/":
            break
    return name_directory[0:i]
    
def go_to_excel():
    name_directory = str(sys.argv[0])
    
    name_directory = pop_end(name_directory)
    name_directory = pop_end(name_directory)
    
    size_start = len("c:/Users/User1/")
    name_directory = name_directory[size_start:]
    
    os.chdir(name_directory)
    # print(os.listdir())



    # def insert_line_id(self, line_id):
    #     request_sql = "INSERT INTO depenses_brutes"
    #     row_elements = self.ExcelAnalyser.get_line_with_id(line_id)
    #     add_to_request = self.elements_line(row_elements)
    #     # self.execute_insert(request_sql)
    
    # def elements_line(self, line_elements):
    #     list_insert = self.return_elements(line_elements)
    #     # column += list_add[0]
    #     # line += list_add[1]
    #     print(list_insert)