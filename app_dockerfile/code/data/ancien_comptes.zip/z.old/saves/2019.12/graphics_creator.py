# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 19:41:52 2019

@author: User1
"""
import matplotlib.pyplot as plt

from words_analyser import WordsAnalyser

class GraphicsAnalyser(WordsAnalyser):
    
    def __init__(self):
        super().__init__()
        
            
    def graphiquePrixDateDuMot(self, mot_a_chercher="", datetime_debut = "debut", datetime_fin = "fin"):
        liste_depenses = self.depensesAvecLeMot(mot_a_chercher, datetime_debut, datetime_fin)
        liste_prix_euro_dollar_date_du_mot = liste_depenses["jour_et_somme"]
        liste_prix_date_du_mot_euros = self.convertionEnEurosDeLaListe(liste_prix_euro_dollar_date_du_mot)
        liste_prix_datetime_du_mot_euros = self.convertionDeDateEnDatetimeDeLaListe(liste_prix_date_du_mot_euros)
        liste_datetime = [element[0] for element in liste_prix_datetime_du_mot_euros]
        liste_prix_euros = [element[1] for element in liste_prix_datetime_du_mot_euros]
        
        plt.scatter(liste_datetime, liste_prix_euros)
        plt.ylabel("prix en €")
        plt.gcf().autofmt_xdate()
        plt.title("Points des dépenses liées au mots : *" + str(mot_a_chercher) + "*")
        plt.show()
        
    
    def graphiqueParTheme(self, theme="courses", datetime_debut = "debut", datetime_fin = "fin"):
        liste_date_prix = self.listeDatePrixDuTheme(theme, datetime_debut, datetime_fin)
        
        plt.bar(liste_date_prix[0], liste_date_prix[1])
        plt.show()

        