# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 19:44:28 2019

@author: User1
"""

from words_analyser import WordsAnalyser

class TripsAnalyser(WordsAnalyser):
    
    def __init__(self):
        super().__init__()
        
        self.path_dates_sorties = self.path_code_data + "\dates_sorties.json"
        self.dates_sorties = self.getDataFromJSON(self.path_dates_sorties)
        self.key_trips = self.getListKeys(self.dates_sorties)

    def depensesSortiesSurPlace(self):
        dictionnaire_complet = {"sortie":[], "depenses":[]}
        for sortie in self.key_trips:
            depenses_sortie = self.depensesSortie(sortie)
            dictionnaire_complet["sortie"].append(sortie)
            dictionnaire_complet["depenses"].append(depenses_sortie)
        return dictionnaire_complet
        
    def depensesSortieSurPlace(self, nom_sortie):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinSortie(nom_sortie)
        (depenses_euros, depenses_dollars) = self.calculDepensesIndiceDebutFin(indice_debut_premier_jour, indice_fin_dernier_jour)
        return (depenses_euros, depenses_dollars)
    
    def depensesTotalesSorties(self):
        dictionnaire_complet = {"sortie":[], "depenses":[]}
        for sortie in self.key_trips:
            depenses_sortie = self.depensesTotalesSortie(sortie)
            dictionnaire_complet["sortie"].append(sortie)
            dictionnaire_complet["depenses"].append(depenses_sortie)
        return dictionnaire_complet
        
    def depensesTotalesSortie(self, nom_sortie):
        (indice_debut, indice_fin) = self.indicesDebutEtFinSortie(nom_sortie)
        (depenses_euros, depenses_dollars) = self.calculDepensesTotales(nom_sortie, indice_debut, indice_fin)
        return (depenses_euros, depenses_dollars)
    
    def indicesDebutEtFinSortie(self, nom_sortie):
        date_debut_periode = self.dates_sorties[nom_sortie]["date_debut"]
        date_fin_perdiode = self.dates_sorties[nom_sortie]["date_fin"]
        
        datetime_debut_periode = self.conversionDateEnDatetime(date_debut_periode)
        datetime_fin_periode = self.conversionDateEnDatetime(date_fin_perdiode)
        
        index_debut_periode = self.indiceDansExcelDuDebutDeLaDate(datetime_debut_periode)
        index_fin_perdiode = self.indiceDansExcelDeLaFinDeLaDate(datetime_fin_periode)
        
        return (index_debut_periode, index_fin_perdiode)
    
    def calculDepensesTotales(self, nom_sortie, indice_debut, indice_fin):
        mot_clef = self.motClefDuVoyage(nom_sortie)
        dict_depenses_preparation_trip = self.depensesAvecLeMot(mot_clef)
        depenses_preparation = dict_depenses_preparation_trip["somme_totale"]
        depenses_sur_place = self.calculDepensesIndiceDebutFin(indice_debut, indice_fin)
        depenses_totales = tuple(x+y for x,y in zip(depenses_preparation, depenses_sur_place))
        return depenses_totales
        
    def nomDeToutesLesSorties(self):
        list_sorties = []
        for nom_sortie in self.key_trips:
            list_sorties.append(nom_sortie)
        return list_sorties
    
    def motClefDuVoyage(self, nom_voyage):
        mot_clef = self.dates_sorties[nom_voyage]["mot_clef"]
        return mot_clef
    

        
        
        