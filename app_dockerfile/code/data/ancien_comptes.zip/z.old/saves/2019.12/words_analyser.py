# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 10:16:11 2019

@author: User1
"""

from basic_analyser import BasicExcelAnalyser
from cleaner import CleanerScript

class WordsAnalyser(BasicExcelAnalyser, CleanerScript):
    
    def __init__(self):
        super().__init__()
        
        
        
    def listeMotsAvecUneErreur(self, mot_a_chercher):
        liste_mot_avec_une_erreur = []
        taille_mot_a_chercher = len(mot_a_chercher)
        if taille_mot_a_chercher <= 2:
            return [mot_a_chercher]
        for i in range(taille_mot_a_chercher):
            mot_a_chercher_avec_une_erreur = list(mot_a_chercher)
            mot_a_chercher_avec_une_erreur.pop(i)
            liste_mot_avec_une_erreur.append("".join(mot_a_chercher_avec_une_erreur))
        return liste_mot_avec_une_erreur
    
    def listeMotsMajMinPremiereLettre(self, mot_a_chercher):
        mot_a_chercher_en_liste = list(mot_a_chercher)
        mot_majuscule_en_liste = mot_a_chercher_en_liste[0].upper()
        mot_minuscule_en_liste = mot_a_chercher_en_liste[0].lower()
        mot_majuscule = "".join(mot_majuscule_en_liste)
        mot_minuscule = "".join(mot_minuscule_en_liste)
        return [mot_majuscule, mot_minuscule]
    
    
    def depensesAvecLesMots(self, mots_a_chercher=[], indice_debut="debut", indice_fin="fin"):
        dictionnaire_complet = {"liste_tuple_trouve":[], "jour_et_somme" :[], "somme_payee":[]}
        for mot in mots_a_chercher:
            dictionnaire_temporaire = self.depensesAvecLeMot(mot, indice_debut, indice_fin)
            dictionnaire_complet["liste_tuple_trouve"].append(dictionnaire_temporaire["liste_tuple_trouve"])
            dictionnaire_complet["jour_et_somme"].append(dictionnaire_temporaire["jour_et_somme"])
            dictionnaire_complet["somme_payee"].append(dictionnaire_temporaire["somme_payee"])
        dictionnaire_complet["liste_tuple_trouve"] = self.nettoyerLaListe(dictionnaire_complet["liste_tuple_trouve"])
        dictionnaire_complet["jour_et_somme"] = self.nettoyerLaListe(dictionnaire_complet["jour_et_somme"])
        dictionnaire_complet["somme_payee"] = self.nettoyerLaListe(dictionnaire_complet["somme_payee"])
    
    def depensesAvecLeMot(self, mot_a_chercher = "", datetime_debut="debut", datetime_fin="fin"):
        if mot_a_chercher == "":
            print("Pas de mot à chercher")
            return 1
        indice_debut = self.convertiDatetimeOuStringEnIndice(datetime_debut)
        indice_fin = self.convertiDatetimeOuStringEnIndice(datetime_fin)
        liste_tuple_trouve = []
        somme_totale = [0,0]
        jour_et_somme = []
        liste_mots_a_tester = self.listeMotsAvecUneErreur(mot_a_chercher)
        for mot in liste_mots_a_tester:
            liste_tuple_indice_expression_prix = self.listeTuplesIndiceDateExpressionPrixDansExcel(mot, indice_debut, indice_fin)
            liste_tuple_trouve.append(liste_tuple_indice_expression_prix)
        liste_tuples_trouve_nettoye = self.nettoyerLaListe(liste_tuple_trouve)
        for indice, date_europ_type, expression, [prix_euros, prix_dollars] in liste_tuples_trouve_nettoye:
            somme_totale[0] += prix_euros
            somme_totale[1] += prix_dollars
            jour_et_somme.append([date_europ_type, (prix_euros, prix_dollars)])
        return {"liste_tuple_trouve" : liste_tuples_trouve_nettoye,
                "jour_et_somme" : jour_et_somme,
                "somme_totale" : somme_totale}
    