# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 19:38:20 2019

@author: User1
"""

class CleanerScript():       

    def nettoyerLaListe(self, liste_a_nettoyer):
        liste_contenant_tous_les_tuples = []
        for sous_liste in liste_a_nettoyer:
            for tuple_dinformations in sous_liste:
                liste_contenant_tous_les_tuples.append(tuple_dinformations)
                
        liste_propre = self.supprimerLesElementsRedondantsDeLaListe(liste_contenant_tous_les_tuples)
        return liste_propre
    
    def supprimerLesElementsRedondantsDeLaListe(self, liste_a_nettoyer):
        elements_a_supprimer = []
        for i in range(len(liste_a_nettoyer)):
            if i+1 > len(liste_a_nettoyer):
                break
            for j in range(i+1, len(liste_a_nettoyer)):
                if liste_a_nettoyer[i] == liste_a_nettoyer[j] or liste_a_nettoyer[i] == []:
                    elements_a_supprimer.append(i)
        elements_a_supprimer = list(set(elements_a_supprimer))
        elements_a_supprimer.sort(reverse=True)
        for i in elements_a_supprimer:
            liste_a_nettoyer.pop(i)
        return liste_a_nettoyer
        
    
    
from basic_analyser import BasicExcelAnalyser


class CleanerExcel(BasicExcelAnalyser):
    
    def __init__(self):
        super().__init__()
        
        
        
        