# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 19:33:05 2019

@author: User1
"""
from basic_analyser import BasicExcelAnalyser

class PeriodsAnalyser(BasicExcelAnalyser):
    
    def __init__(self):
        super().__init__()


        
    def detailsDeLaPeriode(self, indice_debut, indice_fin):
        liste_details = []
        for i in range(indice_debut, indice_fin):
            date_indice = self.valeurDatetimeDansExcel("Quand",i)
            date_indice = self.dateAuFormatEuropeen(date_indice)
            raison_indice = self.valeurStringDansExcel("Quoi",i)
            depenses_euros_indice = self.valeurNombreDansExcel("Dépenses Euros",i)
            depenses_dollars_indice = self.valeurNombreDansExcel("Dépenses Dollars",i)
            non_information = ""
            if raison_indice != non_information:
                liste_details.append((i, date_indice, raison_indice, [depenses_euros_indice, depenses_dollars_indice]))
        return liste_details

    def depensesDeLaSemaine(self, datetime_debut_semaine):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut_semaine, "semaine")
        (depenses_euros, depenses_dollars) = self.calculDepensesIndiceDebutFin(indice_debut_premier_jour, indice_fin_dernier_jour)
        return (depenses_euros, depenses_dollars)
    
    def depensesDuMois(self, datetime_debut_mois):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut_mois, "mois")
        (depenses_euros, depenses_dollars) = self.calculDepensesIndiceDebutFin(indice_debut_premier_jour, indice_fin_dernier_jour)
        return (depenses_euros, depenses_dollars)            
    
    def detailsDesDepensesDeLaPeriode(self, datetime_debut, periode="semaine"):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut, periode)
        details_a_retourner = self.detailsDeLaPeriode(indice_debut_premier_jour, indice_fin_dernier_jour)
        return details_a_retourner  
    
    
    
    