def lolk():
    print("lolk")