

import imp
import sys


sys.path.append(r'C:\Users\User1\Desktop\ENSEA\3A Laval\Semestre 1\BDD avancée\Projet\Remise2\data')
import lolk

