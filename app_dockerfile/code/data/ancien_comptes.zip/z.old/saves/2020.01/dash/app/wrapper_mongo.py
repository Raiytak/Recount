




class VeloEpicurien():
    possible_type_restaurants = []
    
    def __init__(self):
        #Should contain :
        #   mongo_principal
        #   mongo_user
        #   graph_principal
        
        self.optionsUser = OptionsForTrip()
        self.optionsTrip = self.optionsUser.getOptionsForTrip()
        pass
    
    def setCollection_Hexagone(self, radius):
        #Should create a new collection in the mongo_user where
        #restaurants have a field named "hexagon", of radius "radius"
        pass
          
    
    
    

class OptionsForTrip():
    possible_type_restaurants = []
    possible_origin_point = [0,0]
    possible_length = -1
    possible_number_stops = 0
    
    def __init__(self):
        #Should set :
        #   possible_type_restaurants
        #   possible_origin_point
        #   possible_length
        pass
        #Add check steps
    
    def getOptionsForTrip(self):
        origine_point_for_trip = self.getOriginPointForTrip()
        trip_length = self.getTripLength()
        type_restaurants = self.getTripTypeRestaurants()
        number_stops = self.getNumberStops()
        
        options_for_trip = {"origin_point" : origine_point_for_trip,
                            "trip_length" : trip_length,
                            "type_restaurants" : type_restaurants}
        return options_for_trip
        
    def getOriginPointForTrip(self):
        coordinates_origin_point = self.getCoordinatesOriginPoint()
        return coordinates_origin_point
    
    def getCoordinatesOriginPoint(self):
        latitude = input("Donnez la latitude du point d'origine : ")
        longitude = input("Donnez la longitude du point d'origine : ")
        return [latitude, longitude]
        
    def getTripLength(self):
        trip_length = input("Quelle distance voulez-vous parcourir (km)? : ")
        return trip_length
    
    def getTripTypeRestaurants(self):
        print("Voici les différents types de restaurants proposés : ")
        self.printList(self.possible_type_restaurants)
        trip_restaurant_type = self.checkTypeRestaurantExists()
        return trip_restaurant_type
    
    def checkTypeRestaurantExists(self):
        restaurant_type = input("Choisissez un type de restaurant dans la liste : ")
        while restaurant_type not in self.possible_type_restaurants:
            restaurant_type = input("Choisissez un type de restaurant dans la liste svp : ")
        return restaurant_type
        
    def printList(self, list_to_print):
        for element in list_to_print:
            print(element)
        print("\n") 
        
    def getNumberStops(self):
        pass
        
        
class WrapperMongo():
    
    def __init__(self):
        #Should set:
        #   self.mDb
        pass
    
    def getTypeRestaurants(self):
        field_in_db = "fields.categorie"
        #dict_type_restaurants = self.mDb.restaurant.find()
        pass
    
    def getRestaurantsInCercle(self, cercle):
        #Sould return the restaurants using $near with cercle : {position, radius}
        field_in_db = "fields.localisation"
        pass

    def getRestaurantsNearTrip(self, trip):
        #Trip should be a GeoJSON of type polygon that englobes the trip
        #Should return the restaurants in this polygon
        pass
    



class WrapperGraph():
    
    def __init__(self):
        #Should set:
        #   self.gDb
        pass
    
    def proposeRouteForTrip(self, origin, distance):
        pass
    
    def getPolygonEnglobesRouteWithDistance(self, route, distance):
        #Should return a GeoJSON that contains a polygon
        pass
    







