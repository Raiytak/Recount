# -*- coding: utf-8 -*-
"""
Created on Mon Nov  4 20:42:17 2019

@author: etien
"""

import os
from flask import Flask, jsonify
from flask_pymongo import PyMongo

app = Flask(__name__)

app.config['MONGO_DBNAME'] = 'restaurant'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/'

mongo = PyMongo(app)
db = mongo.db

@app.route('/heartbeat', methods=['GET'])
def index():
    nb_restaurant = db.restaurant.count()    
    return jsonify({'nb_restaurants':nb_restaurant})

    
if __name__ == "__main__":
    ENVIRONMENT_DEBUG = os.environ.get("APP_DEBUG", True)
    ENVIRONMENT_PORT = os.environ.get("APP_PORT", 8080)
    app.run(host='0.0.0.0', port=ENVIRONMENT_PORT, debug=ENVIRONMENT_DEBUG)