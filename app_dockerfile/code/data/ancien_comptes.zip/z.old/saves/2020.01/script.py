import os
import sys

CURRENT_PATH = os.getcwd()
PATH_CODE = os.path.join(CURRENT_PATH,"code_data")
sys.path.append(PATH_CODE)


from periods_analyser import PeriodsAnalyser
from graphics_creator import GraphicsAnalyser
from trips_analyser import TripsAnalyser
from cleaner import CleanerExcel

import datetime

class FaireComptes(PeriodsAnalyser, CleanerExcel, TripsAnalyser):
    
    def __init__(self):
        super().__init__()


    def montrerLesDepensesDeLaSemaine(self, datetime_debut):
        details_depenses = self.depensesDeLaSemaine(datetime_debut)
        date_europ_format = self.dateAuFormatEuropeen(datetime_debut)
        print("La semaine du ", date_europ_format,
              "\ntu as dépensé ", details_depenses[0], "€ et ", details_depenses[1], "$ .\n")
        
    def montrerLeDetailDesDepensesDeLaPeriode(self, datetime_debut, periode="semaine"):
        details_depenses = self.detailsDesDepensesDeLaPeriode(datetime_debut)
        for row in details_depenses:
            print(row)
        print("\n")
        
    def montrerDepenseSortiesSurPlace(self, datetime_debut="debut", datetime_fin="fin"):
        dict_trips_expenses = self.depensesSorties()
        list_trips = dict_trips_expenses["sortie"]
        list_trips_expenses = dict_trips_expenses["depenses"]
        number_trips = len(list_trips)
        for i in range(number_trips):
            print(list_trips[i], ":", list_trips_expenses[i])

    def montrerExplicitementLesDepensesAvecLeMot(self, mot_a_chercher="", datetime_debut="debut", datetime_fin="fin"):
        liste_des_depenses = self.depensesAvecLeMot(mot_a_chercher, datetime_debut, datetime_fin)
        print("Le mot cherché est : ", mot_a_chercher)
        for ligne in liste_des_depenses["liste_tuple_trouve"]:
            print(ligne)
        print("Avec comme total : ",  liste_des_depenses["somme_totale"][0], "€ et ",
                                      liste_des_depenses["somme_totale"][1], "$ .\n")
        
    def montrerLesDepensesAvecLeMot(self, mot_a_chercher="", datetime_debut="debut", datetime_fin="fin"):
        liste_des_depenses = self.depensesAvecLeMot(mot_a_chercher, datetime_debut, datetime_fin)
        print("Le mot cherché est : ", mot_a_chercher)
        for ligne in liste_des_depenses["jour_et_somme"]:
            print(ligne)
        print("Avec comme total : ",  liste_des_depenses["somme_totale"][0], "€ et ",
                                      liste_des_depenses["somme_totale"][1], "$ .\n")
            
            
    

annee = 2019
comptes = FaireComptes()
graphic = GraphicsAnalyser()

mot_recherche = "gaa"

mois = 9
jour = 30
datetime1 = datetime.datetime(annee, mois, jour)

mois = 10
jour = 31
datetime2 = datetime.datetime(annee, mois, jour)

#comptes.montrerLesDepensesDeLaSemaine(datetime_type)
#
#comptes.montrerLeDetailDesDepensesDeLaPeriode(datetime_type)
#
#│comptes.montrerDepenseSortiesSurPlace()
#
# print(comptes.nomDeToutesLesSorties())

#print(comptes.montrerExplicitementLesDepensesAvecLeMot(mot_recherche))
#graphic.graphiquePrixDateDuMot(mot_recherche)

#print(comptes.depensesTotalesSorties())

graphic.graphiqueParTheme()



