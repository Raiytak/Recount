# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 09:33:34 2019

@author: Raiytak
"""
import os
import datetime
import pandas as pd
import math
import json
from dateutil.relativedelta import relativedelta


class BasicExcelAnalyser():
    
    def __init__(self):
        self.path_code = os.getcwd()
        self.path_code_data = "code_data"
        
        self.path_theme_abreviation = self.path_code_data + "/theme_abreviation.json"
        self.theme_abreviation = self.getDataFromJSON(self.path_theme_abreviation)
        
        self.path_excel = "credit_etudiant.xlsx"
        self.excel_credit_etudiant = pd.read_excel(self.path_excel)
        
        self.taille_excel = len(self.excel_credit_etudiant["Crédit"])
        self.indice_debut_excel = 0
        self.indice_fin_excel = len(self.excel_credit_etudiant["Quand"])
        self.taux_de_change_euro_dollarC = 1.45
        self.taux_de_change_dollarC_euro = 1/self.taux_de_change_euro_dollarC    
    
    
    def indicesDebutEtFinPeriode(self, date_debut_periode, type_periode):
        indice_debut_periode = self.indiceDansExcelDuDebutDeLaDate(date_debut_periode, "apres")
        if type_periode == "semaine":
            date_fin_periode = self.semaineSuivante(date_debut_periode)
            indice_fin_perdiode = self.indiceDansExcelDeLaFinDeLaDate(date_fin_periode)
        if type_periode == "mois":
            date_fin_periode = self.moisSuivant(date_debut_periode)
            indice_fin_perdiode = self.indiceDansExcelDeLaFinDeLaDate(date_fin_periode)
        return (indice_debut_periode, indice_fin_perdiode)
    
    def calculDepensesIndiceDebutFin(self, indice_debut, indice_fin):
        somme_depenses_euros,somme_depenses_dollars = 0,0
        for i in range(indice_debut, indice_fin):
            depense_euros = self.valeurNombreDansExcel("Dépenses Euros", i)
            depense_dollars = self.valeurNombreDansExcel("Dépenses Dollars", i)
            somme_depenses_euros += depense_euros
            somme_depenses_dollars += depense_dollars
        return (somme_depenses_euros, somme_depenses_dollars)
            
    def indiceDansExcelDuDebutDeLaDate(self, date_a_trouver = 0, avant_ou_apres = "avant"):
        if type(date_a_trouver) != datetime.datetime:
            print("Date pas de type datetime.datetime")
            return 1
        #Vérification de la date :
        if date_a_trouver > datetime.datetime.today():
            print("Vous demandez un jour dans le futur, jour demandé : ", date_a_trouver)
            return 1
        if date_a_trouver < datetime.datetime(2018,1,1):
            print("Vous demandez un jour dans le passé inexistant")
            return 1
        for i in range(self.taille_excel):
            if self.valeurDatetimeDansExcel("Quand",i) == date_a_trouver:
                return i
        if avant_ou_apres == "avant":
            date_a_trouver = self.jourPrecedant(date_a_trouver)
        elif avant_ou_apres == "apres":
            date_a_trouver = self.jourSuivant(date_a_trouver)
        return self.indiceDansExcelDuDebutDeLaDate(date_a_trouver, avant_ou_apres)
    
    def indiceDansExcelDeLaFinDeLaDate(self, date_a_trouver = 0, avant_ou_apres = "avant"):
        date_suivant_date_a_trouver = self.jourSuivant(date_a_trouver)
        index_date_suivante = self.indiceDansExcelDuDebutDeLaDate(date_suivant_date_a_trouver, "apres")
        indice_fin_date_a_trouver = index_date_suivante -1
        return indice_fin_date_a_trouver
    
    def valeurNombreDansExcel(self, colonne, ligne):
        valeur_excel = self.excel_credit_etudiant[colonne][ligne]
        if type(valeur_excel) not in [float, int]:
            #print("La valeur colonne ", colonne, "ligne ", ligne, "n'est pas un nombre")
            return 0
        if math.isnan(valeur_excel):
            return 0
        return valeur_excel
    
    def valeurStringDansExcel(self, colonne, index):
        valeur_excel = self.excel_credit_etudiant[colonne][index]
        if type(valeur_excel) == str:
            return valeur_excel
        return ""
    
    def valeurDatetimeDansExcel(self, colonne, indice):
        valeur_excel = self.excel_credit_etudiant[colonne][indice]
        if type(valeur_excel) == datetime.datetime:
            return valeur_excel
        return 0

    def jourSuivant(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 1)
    
    def jourPrecedant(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 1)
        
    def semaineSuivante(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 7)   
     
    def semainePrecedante(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 7)
        
    def moisSuivant(self, date_fournie):
        return date_fournie + relativedelta(months = 1)   
     
    def moisPrecedant(self, date_fournie):
        return date_fournie - relativedelta(months = 1)  
        
    def dateAuFormatEuropeen(self, datetime_type):
        if type(datetime_type) != datetime.datetime:
            return "-"
        return str(datetime_type.day)+"/"+str(datetime_type.month)+"/"+str(datetime_type.year)
    
    def datetimeOuNonInformation(self, datetime_type):
        print("coucou", datetime_type)
        if datetime_type.year < 2000:
            return "non information"
        return"datetime"
        
    def conversionDateEnDatetime(self, date_a_convertir):
        datetime_a_retourner = datetime.datetime.strptime(date_a_convertir, "%d/%m/%Y")
        return datetime_a_retourner    
    
    def listeTuplesIndiceDateExpressionPrixDansExcel(self, regex_expression, datetime_debut = "debut", datetime_fin = "fin"):
        indice_debut = self.convertiDatetimeOuStringEnIndice(datetime_debut)
        indice_fin = self.convertiDatetimeOuStringEnIndice(datetime_fin)
        liste_indice_date_quoi_prix_a_retourner = []
        for i in range(indice_debut, indice_fin):
            if regex_expression in self.valeurStringDansExcel("Quoi",i):
                liste_indice_date_quoi_prix_a_retourner.append(self.appendIndiceDateQuoiPrixDeLaLigne(i))
        return liste_indice_date_quoi_prix_a_retourner
    
    def appendIndiceDateQuoiPrixDeLaLigne(self, indice):
        datetime_type = self.dateDansExcelDeLaLigne(indice)
        date_europ_type = self.dateAuFormatEuropeen(datetime_type)
        quoi_excel = self.valeurStringDansExcel("Quoi",indice)
        prix_euros_excel = self.valeurNombreDansExcel("Dépenses Euros",indice)
        prix_dollars_excel = self.valeurNombreDansExcel("Dépenses Dollars",indice)
        liste_prix = [prix_euros_excel, prix_dollars_excel]
        return (indice, date_europ_type, quoi_excel, liste_prix)
        
    def convertiDatetimeOuStringEnIndice(self, element_a_convertir):
        if type(element_a_convertir) == str:
            return self.convertiStringEnIndice(element_a_convertir)
        elif type(element_a_convertir) == datetime.datetime:
            return self.indiceDansExcelDuDebutDeLaDate(element_a_convertir)
        return element_a_convertir
    
    def convertiStringEnIndice(self, indice_a_initialiser):
        if indice_a_initialiser == "debut":
            return self.indice_debut_excel
        elif indice_a_initialiser == "fin":
            return self.indice_fin_excel
        return indice_a_initialiser #RAISE EXCEPTION
    
    def dateDansExcelDeLaLigne(self, indice_a_chercher=0):
        indice_temporaire = indice_a_chercher
        while indice_temporaire > 0:
            jour_ou_case_vide = self.valeurDatetimeDansExcel("Quand",indice_temporaire)
            if type(jour_ou_case_vide) == datetime.datetime:
                return jour_ou_case_vide
            indice_temporaire -= 1
        print("La date n'existe pas pour la ligne ", indice_a_chercher)
        return 0
        
    def convertionEnEurosDeLaListe(self, liste_a_convertir):
        if liste_a_convertir == []:
            return []
        indice_de_la_liste_euro_dollar = self.indiceDeLaListeEuroDollar(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            depense_en_euros = self.conversionEnEurosDe(une_ligne_de_la_liste_a_convertir[indice_de_la_liste_euro_dollar])
            liste_brute[indice_de_la_liste_euro_dollar] = depense_en_euros
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
            
    def indiceDeLaListeEuroDollar(self, liste_a_convertir):
        indice_liste_euro_dollar = 0
        for element_ligne in liste_a_convertir[0]:
            if (type(element_ligne) == tuple) or (type(element_ligne) == list):
                return indice_liste_euro_dollar
            indice_liste_euro_dollar += 1
        print("Liste euro dollar non trouvée dans la liste : ", liste_a_convertir)
        return -1
    
    def conversionEnEurosDe(self, liste_euro_dollar):
        depense_euros = liste_euro_dollar[0]
        depense_dollars_converti_en_euros = liste_euro_dollar[1]*self.taux_de_change_dollarC_euro
        return depense_euros + depense_dollars_converti_en_euros
    
    def convertionDeDateEnDatetimeDeLaListe(self, liste_a_convertir):
        indice_de_la_date = self.indiceDeLaDate(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            datetime_de_la_date = self.conversionDateEnDatetime(une_ligne_de_la_liste_a_convertir[indice_de_la_date])
            liste_brute[indice_de_la_date] = datetime_de_la_date
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
    
    def indiceDeLaDate(self, liste_a_convertir):
        if liste_a_convertir == []:
            return []
        indice_date = 0
        for element_ligne in liste_a_convertir[0]:
#            print(element_ligne)
            if (type(element_ligne) == str) and (type(int(element_ligne[0])) == int):
                return indice_date
            indice_date += 1
        print("Date non trouvée dans la liste : ", liste_a_convertir)
        return -1



    def getListKeys(self, dict_to_analyse):
        list_keys = []
        for key in dict_to_analyse:
            list_keys.append(key)
        return list_keys
    
    def getDataFromJSON(self, path_json_to_import):
        with open(path_json_to_import,"r") as raw_data:
            ret_data = json.load(raw_data)
            return ret_data
        
    
    
    def listeDatePrixDuTheme(self, theme="", datetime_debut = "debut", datetime_fin = "fin"):
        list_date,list_prix = [],[]
        list_indices = self.trouveIndicesDuTheme(theme, datetime_debut, datetime_fin)
        for indice in list_indices:
            date_indice = self.dateDansExcelDeLaLigne(indice)
            list_date.append(date_indice)
            prix_indice = self.prixEuroDeLaLigne(indice)
            list_prix.append(prix_indice)
        return [list_date, list_prix]
    
    def trouveIndicesDuTheme(self, theme="", datetime_debut = "debut", datetime_fin = "fin"):
        list_indices = []
        theme_abreviation = self.retourneAbreviationDuTheme(theme)
        for i in range(self.taille_excel):
            if theme_abreviation in self.excel_credit_etudiant["Thème"]:
                list_indices.append(i)
        return list_indices
    
    def retourneAbreviationDuTheme(self, theme):
        if theme == "courses":
            return "c:"
    
    def prixEuroDeLaLigne(self, indice):
        prix_euros = self.excel_credit_etudiant["Dépenses Euros"][indice]
        prix_dollars = self.excel_credit_etudiant["Dépenses Dollars"][indice]
        list_euros_dollars = [prix_euros, prix_dollars]
        prix_euros_total = self.conversionEnEurosDe(list_euros_dollars)
        return prix_euros_total