import sys
sys.path.append("code_data")
from basic_analyser import BasicExcelAnalyser
import matplotlib.pyplot as plt
import json

class FaireComptes(BasicExcelAnalyser):
    
    def __init__(self, path_excel):
        super().__init__(path_excel)
        """
        self.excel_credit_etudiant = pd.read_excel("credit_etudiant.xlsx")
        self.taille_excel = len(self.excel_credit_etudiant["Crédit"])
        self.indice_debut_excel = 0
        self.indice_fin_excel = len(self.excel_credit_etudiant["Quand"])
        self.taux_de_change_euro_dollarC = 1.45
        self.taux_de_change_dollarC_euro = 1/self.taux_de_change_euro_dollarC
        self.date_sortie = self.importDataFrom_dates_sorties()
        """

    def depensesDeLaSemaine(self, datetime_debut_semaine):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut_semaine, "semaine")
        (depenses_euros, depenses_dollars) = self.calculDepensesIndiceDebutFin(indice_debut_premier_jour, indice_fin_dernier_jour)
        return (depenses_euros, depenses_dollars)
    
    def depensesDuMois(self, datetime_debut_mois):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut_mois, "mois")
        (depenses_euros, depenses_dollars) = self.calculDepensesIndiceDebutFin(indice_debut_premier_jour, indice_fin_dernier_jour)
        return (depenses_euros, depenses_dollars)            
    
    def detailsDesDepensesDeLaPeriode(self, datetime_debut, periode="semaine"):
        (indice_debut_premier_jour, indice_fin_dernier_jour) = self.indicesDebutEtFinPeriode(datetime_debut, periode)
        details_a_retourner = self.detailsDeLaPeriode(indice_debut_premier_jour, indice_fin_dernier_jour)
        return details_a_retourner
    
    def montrerLesDepensesDeLaSemaine(self, datetime_debut):
        details_depenses = self.depensesDeLaSemaine(datetime_debut)
        date_europ_format = self.dateAuFormatEuropeen(datetime_debut)
        print("La semaine du ", date_europ_format,
              "\ntu as dépensé ", details_depenses[0], "€ et ", details_depenses[1], "$ .\n")
        
    def montrerLeDetailDesDepensesDeLaPeriode(self, datetime_debut, periode="semaine"):
        details_depenses = self.detailsDesDepensesDeLaPeriode(datetime_debut)
        for row in details_depenses:
            print(row)
        print("\n")
        
        
    """
    def indicesDebutEtFinPeriode(self, date_debut_periode, type_periode):
        index_debut_periode = self.indiceDansExcelDeLaDate(date_debut_periode, "apres")
        if type_periode == "semaine":
            date_fin_periode = self.semaineSuivante(date_debut_periode)
            index_fin_perdiode = self.indiceDansExcelDeLaFinDeLaDate(date_fin_periode)
        if type_periode == "mois":
            date_fin_periode = self.moisSuivant(date_debut_periode)
            index_fin_perdiode = self.indiceDansExcelDeLaFinDeLaDate(date_fin_periode)
        return (index_debut_periode, index_fin_perdiode)
    
    def calculDepensesIndiceDebutFin(self, index_debut, index_fin):
        somme_depenses_euros,somme_depenses_dollars = 0,0
        for i in range(index_debut, index_fin):
            depense_euros = self.valeurNombreDansExcel("Dépenses Euros", i)
            depense_dollars = self.valeurNombreDansExcel("Dépenses Dollars", i)
            somme_depenses_euros += depense_euros
            somme_depenses_dollars += depense_dollars
        return (somme_depenses_euros, somme_depenses_dollars)
            
    def indiceDansExcelDeLaDate(self, date_a_trouver = 0, avant_ou_apres = "avant"):
        if type(date_a_trouver) != datetime.datetime:
            print("Date pas de type datetime.datetime")
            return 1
        #Vérification de la date :
        if date_a_trouver > datetime.datetime.today():
            print("Vous demandez un jour dans le futur, jour demandé : ", date_a_trouver)
            return 1
        if date_a_trouver < datetime.datetime(2018,1,1):
            print("Vous demandez un jour dans le passé inexistant")
            return 1
        for i in range(self.taille_excel):
            if self.valeurDatetimeDansExcel("Quand",i) == date_a_trouver:
                return i
        if avant_ou_apres == "avant":
            date_a_trouver = self.jourPrecedant(date_a_trouver)
        elif avant_ou_apres == "apres":
            date_a_trouver = self.jourSuivant(date_a_trouver)
        return self.indiceDansExcelDeLaDate(date_a_trouver, avant_ou_apres)
    
    def indiceDansExcelDeLaFinDeLaDate(self, date_a_trouver = 0, avant_ou_apres = "avant"):
        date_suivant_date_a_trouver = self.jourSuivant(date_a_trouver)
        index_date_suivante = self.indiceDansExcelDeLaDate(date_suivant_date_a_trouver, "apres")
        index_fin_date_a_trouver = index_date_suivante -1
        return index_fin_date_a_trouver
    
    def detailsDeLaPeriode(self, indice_debut, indice_fin):
        liste_details = []
        for i in range(indice_debut, indice_fin):
            date_indice = self.valeurDatetimeDansExcel("Quand",i)
            date_indice = self.dateAuFormatEuropeen(date_indice)
            raison_indice = self.valeurStringDansExcel("Quoi",i)
            depenses_euros_indice = self.valeurNombreDansExcel("Dépenses Euros",i)
            depenses_dollars_indice = self.valeurNombreDansExcel("Dépenses Dollars",i)
            non_information = ""
            if raison_indice != non_information:
                liste_details.append((i, date_indice, raison_indice, [depenses_euros_indice, depenses_dollars_indice]))
        return liste_details
    
    def valeurNombreDansExcel(self, colonne, ligne):
        valeur_excel = self.excel_credit_etudiant[colonne][ligne]
        if type(valeur_excel) not in [float, int]:
            #print("La valeur colonne ", colonne, "ligne ", ligne, "n'est pas un nombre")
            return 0
        if math.isnan(valeur_excel):
            return 0
        return valeur_excel
    
    def valeurStringDansExcel(self, colonne, index):
        valeur_excel = self.excel_credit_etudiant[colonne][index]
        if type(valeur_excel) == str:
            return valeur_excel
        return ""
    
    def valeurDatetimeDansExcel(self, colonne, indice):
        valeur_excel = self.excel_credit_etudiant[colonne][indice]
        if type(valeur_excel) == datetime.datetime:
            return valeur_excel
        return 0

    def jourSuivant(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 1)
    
    def jourPrecedant(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 1)
        
    def semaineSuivante(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 7)   
     
    def semainePrecedante(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 7)
        
    def moisSuivant(self, date_fournie):
        return date_fournie + relativedelta(months = 1)   
     
    def moisPrecedant(self, date_fournie):
        return date_fournie - relativedelta(months = 1)  
        
    def dateAuFormatEuropeen(self, datetime_type):
        if type(datetime_type) != datetime.datetime:
            return "-"
        return str(datetime_type.day)+"/"+str(datetime_type.month)+"/"+str(datetime_type.year)
    
    def datetimeOuNonInformation(self, datetime_type):
        print("coucou", datetime_type)
        if datetime_type.year < 2000:
            return "non information"
        return"datetime"
    """
    
    
    def depensesAvecLesMots(self, mots_a_chercher=[], indice_debut="debut", indice_fin="fin"):
        dictionnaire_complet = {"liste_tuple_trouve":[], "jour_et_somme" :[], "somme_payee":[]}
        for mot in mots_a_chercher:
            dictionnaire_temporaire = self.depensesAvecLeMot(mot, indice_debut, indice_fin)
            dictionnaire_complet["liste_tuple_trouve"].append(dictionnaire_temporaire["liste_tuple_trouve"])
            dictionnaire_complet["jour_et_somme"].append(dictionnaire_temporaire["jour_et_somme"])
            dictionnaire_complet["somme_payee"].append(dictionnaire_temporaire["somme_payee"])
        dictionnaire_complet["liste_tuple_trouve"] = self.nettoyerLaListe(dictionnaire_complet["liste_tuple_trouve"])
        dictionnaire_complet["jour_et_somme"] = self.nettoyerLaListe(dictionnaire_complet["jour_et_somme"])
        dictionnaire_complet["somme_payee"] = self.nettoyerLaListe(dictionnaire_complet["somme_payee"])
    
    def depensesAvecLeMot(self, mot_a_chercher = "", datetime_debut="debut", datetime_fin="fin"):
        if mot_a_chercher == "":
            print("Pas de mot à chercher")
            return 1
        indice_debut = self.convertiDatetimeOuStringEnIndice(datetime_debut)
        indice_fin = self.convertiDatetimeOuStringEnIndice(datetime_fin)
        liste_tuple_trouve = []
        somme_totale = [0,0]
        jour_et_somme = []
        liste_mots_a_tester = self.listeMotsAvecUneErreur(mot_a_chercher)
        for mot in liste_mots_a_tester:
            liste_tuple_indice_expression_prix = self.listeTuplesIndiceDateExpressionPrixDansExcel(mot, indice_debut, indice_fin)
            liste_tuple_trouve.append(liste_tuple_indice_expression_prix)
        liste_tuples_trouve_nettoye = self.nettoyerLaListe(liste_tuple_trouve)
        for indice, date_europ_type, expression, [prix_euros, prix_dollars] in liste_tuples_trouve_nettoye:
            somme_totale[0] += prix_euros
            somme_totale[1] += prix_dollars
            jour_et_somme.append([date_europ_type, (prix_euros, prix_dollars)])
        return {"liste_tuple_trouve" : liste_tuples_trouve_nettoye,
                "jour_et_somme" : jour_et_somme,
                "somme_totale" : somme_totale}
    
    def montrerLesDepensesAvecLeMot(self, mot_a_chercher = "", datetime_debut=0, datetime_fin=0):
        liste_des_depenses = self.depensesAvecLeMot(mot_a_chercher, datetime_debut, datetime_fin)
        print("Le mot cherché est : ", mot_a_chercher)
        for ligne in liste_des_depenses["jour_et_somme"]:
            print(ligne)
        print("Avec comme total : ",  liste_des_depenses["somme_totale"][0], "€ et ",
                                      liste_des_depenses["somme_totale"][1], "$ .\n")
    
    def montrerExplicitementLesDepensesAvecLeMot(self, mot_a_chercher = "", datetime_debut="debut", datetime_fin="fin"):
        liste_des_depenses = self.depensesAvecLeMot(mot_a_chercher, datetime_debut, datetime_fin)
        print("Le mot cherché est : ", mot_a_chercher)
        for ligne in liste_des_depenses["liste_tuple_trouve"]:
            print(ligne)
        print("Avec comme total : ",  liste_des_depenses["somme_totale"][0], "€ et ",
                                      liste_des_depenses["somme_totale"][1], "$ .\n")
        
    def importDataFrom_dates_sorties(self):
        with open(r"code_data/dates_sorties.json","r") as raw_data:
            data = json.load(raw_data)
            return data
    ####
    def listeMotsAvecUneErreur(self, mot_a_chercher):
        liste_mot_avec_une_erreur = []
        taille_mot_a_chercher = len(mot_a_chercher)
        for i in range(taille_mot_a_chercher):
            mot_a_chercher_avec_une_erreur = list(mot_a_chercher)
            mot_a_chercher_avec_une_erreur.pop(i)
            liste_mot_avec_une_erreur.append("".join(mot_a_chercher_avec_une_erreur))
        return liste_mot_avec_une_erreur
    
    def listeMotsMajMinPremiereLettre(self, mot_a_chercher):
        mot_a_chercher_en_liste = list(mot_a_chercher)
        mot_majuscule_en_liste = mot_a_chercher_en_liste[0].upper()
        mot_minuscule_en_liste = mot_a_chercher_en_liste[0].lower()
        mot_majuscule = "".join(mot_majuscule_en_liste)
        mot_minuscule = "".join(mot_minuscule_en_liste)
        return [mot_majuscule, mot_minuscule]
            
    def listeTuplesIndiceDateExpressionPrixDansExcel(self, regex_expression, datetime_debut = "debut", datetime_fin = "fin"):
        indice_debut = self.convertiDatetimeOuStringEnIndice(datetime_debut)
        indice_fin = self.convertiDatetimeOuStringEnIndice(datetime_fin)
        liste_indice_date_quoi_prix_a_retourner = []
        for i in range(indice_debut, indice_fin):
            if regex_expression in self.valeurStringDansExcel("Quoi",i):
                liste_indice_date_quoi_prix_a_retourner.append(self.appendIndiceDateQuoiPrixDeLaLigne(i))
        return liste_indice_date_quoi_prix_a_retourner
    
    def nettoyerLaListe(self, liste_a_nettoyer):
        liste_contenant_tous_les_tuples = []
        for sous_liste in liste_a_nettoyer:
            for tuple_dinformations in sous_liste:
                liste_contenant_tous_les_tuples.append(tuple_dinformations)
                
        liste_propre = self.supprimerLesElementsRedondantsDeLaListe(liste_contenant_tous_les_tuples)
        return liste_propre
    
    def supprimerLesElementsRedondantsDeLaListe(self, liste_a_nettoyer):
        elements_a_supprimer = []
        for i in range(len(liste_a_nettoyer)):
            if i+1 > len(liste_a_nettoyer):
                break
            for j in range(i+1, len(liste_a_nettoyer)):
                if liste_a_nettoyer[i] == liste_a_nettoyer[j] or liste_a_nettoyer[i] == []:
                    elements_a_supprimer.append(i)
        elements_a_supprimer = list(set(elements_a_supprimer))
        elements_a_supprimer.sort(reverse=True)
        for i in elements_a_supprimer:
            liste_a_nettoyer.pop(i)
        return liste_a_nettoyer
    
    def appendIndiceDateQuoiPrixDeLaLigne(self, indice):
        datetime_type = self.dateDansExcelDeLaLigne(indice)
        date_europ_type = self.dateAuFormatEuropeen(datetime_type)
        quoi_excel = self.valeurStringDansExcel("Quoi",indice)
        prix_euros_excel = self.valeurNombreDansExcel("Dépenses Euros",indice)
        prix_dollars_excel = self.valeurNombreDansExcel("Dépenses Dollars",indice)
        liste_prix = [prix_euros_excel, prix_dollars_excel]
        return (indice, date_europ_type, quoi_excel, liste_prix)
        
    def convertiDatetimeOuStringEnIndice(self, element_a_convertir):
        if type(element_a_convertir) == str:
            return self.convertiStringEnIndice(element_a_convertir)
        elif type(element_a_convertir) == datetime.datetime:
            return self.indiceDansExcelDeLaDate(element_a_convertir)
        return element_a_convertir
    
    def convertiStringEnIndice(self, indice_a_initialiser):
        if indice_a_initialiser == "debut":
            return self.indice_debut_excel
        elif indice_a_initialiser == "fin":
            return self.indice_fin_excel
        return indice_a_initialiser
    
    def dateDansExcelDeLaLigne(self, indice_a_chercher=0):
        indice_temporaire = indice_a_chercher
        while indice_temporaire > 0:
            jour_ou_case_vide = self.valeurDatetimeDansExcel("Quand",indice_temporaire)
            if type(jour_ou_case_vide) == datetime.datetime:
                return jour_ou_case_vide
            indice_temporaire -= 1
        print("La date n'existe pas pour la ligne ", indice_a_chercher)
        return 0
    
    
    def graphiquePrixDateDuMot(self, mot_a_chercher="", datetime_debut = "debut", datetime_fin = "fin"):
        liste_depenses = self.depensesAvecLeMot(mot_a_chercher)
        liste_prix_euro_dollar_date_du_mot = liste_depenses["jour_et_somme"]
        liste_prix_date_du_mot_euros = self.convertionEnEurosDeLaListe(liste_prix_euro_dollar_date_du_mot)
        liste_prix_datetime_du_mot_euros = self.convertionDeDateEnDatetimeDeLaListe(liste_prix_date_du_mot_euros)
        liste_datetime = [element[0] for element in liste_prix_datetime_du_mot_euros]
        liste_prix_euros = [element[1] for element in liste_prix_datetime_du_mot_euros]
        plt.scatter(liste_datetime, liste_prix_euros)
        plt.gcf().autofmt_xdate()
        plt.title("Points des dépenses liées au mots : " + str(mot_a_chercher))
        plt.show()
        
    def convertionEnEurosDeLaListe(self, liste_a_convertir):
        indice_de_la_liste_euro_dollar = self.indiceDeLaListeEuroDollar(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            depense_en_euros = self.conversionEnEurosDe(une_ligne_de_la_liste_a_convertir[indice_de_la_liste_euro_dollar])
            liste_brute[indice_de_la_liste_euro_dollar] = depense_en_euros
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
            
    def indiceDeLaListeEuroDollar(self, liste_a_convertir):
        indice_liste_euro_dollar = 0
        for element_ligne in liste_a_convertir[0]:
            if (type(element_ligne) == tuple) or (type(element_ligne) == list):
                return indice_liste_euro_dollar
            indice_liste_euro_dollar += 1
        print("Liste euro dollar non trouvée dans la liste : ", liste_a_convertir)
        return -1
    
    def conversionEnEurosDe(self, liste_euro_dollar):
        depense_euros = liste_euro_dollar[0]
        depense_dollars_converti_en_euros = liste_euro_dollar[1]*self.taux_de_change_dollarC_euro
        return depense_euros + depense_dollars_converti_en_euros
    
    def convertionDeDateEnDatetimeDeLaListe(self, liste_a_convertir):
        indice_de_la_date = self.indiceDeLaDate(liste_a_convertir)
        liste_a_retourner = []
        for une_ligne_de_la_liste_a_convertir in liste_a_convertir:
            liste_brute = list(une_ligne_de_la_liste_a_convertir)
            datetime_de_la_date = self.conversionDateEnDatetime(une_ligne_de_la_liste_a_convertir[indice_de_la_date])
            liste_brute[indice_de_la_date] = datetime_de_la_date
            liste_a_retourner.append(liste_brute)
        return liste_a_retourner
    
    def indiceDeLaDate(self, liste_a_convertir):
        indice_date = 0
        for element_ligne in liste_a_convertir[0]:
            print(element_ligne)
            if (type(element_ligne) == str) and (type(int(element_ligne[0])) == int):
                return indice_date
            indice_date += 1
        print("Date non trouvée dans la liste : ", liste_a_convertir)
        return -1
    
    def conversionDateEnDatetime(self, date_a_convertir):
        datetime_a_retourner = datetime.datetime.strptime(date_a_convertir, "%d/%m/%Y")
        return datetime_a_retourner
    
    def montrerDepensesSortie(self, nom_sortie):
        for key in self.date_sortie:
            print(key)
    
    def indicesDebutEtFinSortie(self, nom_sortie):
        pass
    
    def rentrerNouvelleSortie(self):
        pass
        
    
#class nettoyerExcel():
#    def __init__(self, chemin_a_excel):
#        self.fichier_excel = 
    

PATH_EXCEL = "credit_etudiant.xlsx"
comptes = FaireComptes(PATH_EXCEL)
annee = 2019
mois = 10
jour = 15
datetime_type = datetime.datetime(annee, mois, jour)

comptes.montrerLesDepensesDeLaSemaine(datetime_type)
#
#comptes.montrerLeDetailDesDepensesDeLaPeriode(datetime_type)
#
#depenses_mot = comptes.montrerExplicitementLesDepensesAvecLeMot("ff")

comptes.montrerDepensesSortie("salu")

