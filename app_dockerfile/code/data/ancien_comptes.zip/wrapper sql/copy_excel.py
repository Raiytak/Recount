# -*- coding: utf-8 -*-

import os
import sys
from shutil import copyfile

class CopyExcel():
    
    def __init__(self):
        self.path_code = os.getcwd()
        self.path_excel = "credit_etudiant.xlsx"
        
        self.data_path = self.getDataPath()
        self.project_excel = self.getProjectExcelPath()
        self.real_excel = self.getRealExcelPath()
    
    
    def copyExcelToData(self):
        copyfile(self.real_excel, self.project_excel)
        os.chdir(self.data_path)

    def popEnd(self, name_directory):
        size = len(name_directory)
        for i in range(size-1,0,-1):
            if name_directory[i] == "/":
                break
        return name_directory[0:i]
        
    def getRealExcelPath(self):
        path_excel = r"C:\Users\User1\Desktop\Le Dossier\Comptes\credit_etudiant.xlsx"
        return path_excel
    
    def getDataPath(self):
        data_path = str(sys.argv[0])
        self.popEnd(data_path)
        self.popEnd(data_path)
        data_path += "/data"
        
        return data_path
    
    def getProjectExcelPath(self):
        project_excel_path = self.getDataPath() + "/credit_etudiant.xlsx"
        
        return project_excel_path
