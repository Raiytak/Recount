from transfer_SQL import OperationSQL
import datetime

myTransfert = OperationSQL()

start_datetime = datetime.datetime(2019,8,1)
end_datetime = datetime.datetime.now()


