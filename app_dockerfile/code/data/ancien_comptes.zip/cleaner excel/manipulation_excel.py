# -*- coding: utf-8 -*-

import os
import sys
from shutil import copyfile

import numpy as np
import pandas as pd

from utility_fct import *



class CopyExcel():
    
    def __init__(self):
        self.path_code = os.getcwd()
        self.path_excel = "credit_etudiant.xlsx"
        
        self.data_path = self.getDataPath()
        self.project_excel = self.getProjectExcelPath()
        self.real_excel = self.getRealExcelPath()
    
    
    def copyExcelToData(self):
        # try:
        #     os.remove(self.project_excel)
        # except FileNotFoundError:
        #     pass
        copyfile(self.real_excel, self.project_excel)

    def popEnd(self, name_directory):
        size = len(name_directory)
        for i in range(size-1,0,-1):
            if name_directory[i] == "/":
                break
        return name_directory[0:i]
        
    def getRealExcelPath(self):
        path_excel = r"C:\Users\User1\Desktop\Le Dossier\Comptes\credit_etudiant.xlsx"
        return path_excel
    
    def getDataPath(self):
        # data_path = str(sys.argv[0])
        # self.popEnd(data_path)
        # self.popEnd(data_path)
        # data_path += "/data"
        
        path_data = r"C:\Users\User1\Desktop\Projets\Comptes\data"
        
        return path_data
    
    def getProjectExcelPath(self):
        project_excel_path = self.getDataPath() + "/credit_etudiant.xlsx"
        
        return project_excel_path

    def moveToCurrentDir(self):
        os.chdir(self.data_path)
        
        

class ExcelAccessor():
    def __init__(self):
        self._path = self.getPathToExcel()
        self._dataframe = self.getCurrentExcelInDatframe()
        
    def getPathToExcel(self):
        _path = r"C:\Users\User1\Desktop\Projets\Comptes\data"
        name = "credit_etudiant.xlsx"
        return _path + "/" + name
    
    def getCurrentExcelInDatframe(self):
        xl_file = pd.ExcelFile(self._path)
        dfs = {sheet_name: xl_file.parse(sheet_name) 
                for sheet_name in xl_file.sheet_names}
        return dfs["Feuil1"]
    
    def getDataframe(self):
        return self._dataframe
    
    
    

class ExcelCleaner(ExcelAccessor):
    def __init__(self):
        super().__init__()
        
    
    def updateExcel(self):
        self._dataframe.to_excel(self._path, sheet_name="Feuil1")
        
    def cleanExcel(self):
        self.removeUselessColumsAndRows()
        self.removeSummationLines()
        self.removeAccentAndApostrophe()
        
    def removeUselessColumsAndRows(self):
        self.removeUselessColums()
        self.removeUselessRows()        
    
    def removeUselessColums(self):
        list_useless_columns = ["Sommes E", "Sommes D",
                                "Somme euro", "Somme dollar",
                                "Excédentaires E", "Excédentaires D"]
        for column in list_useless_columns:
            try:
                self._dataframe.drop(column, inplace=True, axis=1)
            except KeyError:
                print("Column already removed")
        #Remove the columns added with the manipulations
        try:
            self._dataframe.drop("Unnamed: 0", inplace=True, axis=1)
        except KeyError:
            print("No unnamed colunm to remove")
    
    def removeUselessRows(self):
        list_useless_rows = [0]
        for row in list_useless_rows:
            try:
                self._dataframe.drop(row, inplace=True, axis=0)
            except KeyError:
                print("Row already removed")
    
    
    def addDateEverywhere(self):
        last_date = np.datetime64("2019-07-01")
        
        for i in range(len(self.getDataframe())):
            current_date = self.getDataframe().loc[i,"Quand"]
            
            if pd.isnull(current_date):
                self.getDataframe().at[i,"Quand"] = last_date
            else:
                last_date = current_date
    
    def removeSummationLines(self):
        dataframe = self.getDataframe()
        dataframe = dataframe[dataframe["Dépenses Euros"].notnull() | dataframe["Dépenses Dollars"].notnull()]
        self._dataframe = dataframe
        
    def removeAccentAndApostrophe(self):
        dataframe = self._dataframe
        dataframe["Quoi"] = dataframe["Quoi"].apply(removeAccentAndApostropheInStr)
        self._dataframe = dataframe
    
    def getExpenseInEuros(self, row):
        print(row)
        expenseE, expenseD = self.getExpenseValue(row)
        return expenseE + (expenseD/1.5)
    
    def getExpenseValue(self, row): #REPLACE WITH .add(..., fill_value=0)
        expenseE = row["Dépenses Euros"]
        expenseD = row["Dépenses Dollars"]
        if pd.isnull(expenseE):
            expenseE = 0
        if pd.isnull(expenseD):
            expenseD = 0
        return expenseE, expenseD
        
        
    def end(self):
        self.updateExcel()