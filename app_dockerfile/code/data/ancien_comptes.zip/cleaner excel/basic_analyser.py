# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 09:33:34 2019

@author: Raiytak
"""
import os
import copy_excel
import datetime
import math
import json
import pandas as pd
from dateutil.relativedelta import relativedelta


class BasicExcelAnalyser():
    
    def __init__(self):
        myCopy = copy_excel.CopyExcel()
        myCopy.moveToCurrentDir()
        
        self.path_code = os.getcwd()
        self.path_code_data = "code_data"
        
        self.path_excel = "credit_etudiant.xlsx"
        self.excel_credit_etudiant = pd.read_excel(self.path_excel) #opened or FileNotFoundError
        
        self.len_excel = len(self.excel_credit_etudiant["ID"])
        self.indice_start_excel = 2
        self.indice_end_excel = len(self.excel_credit_etudiant["Quand"])
        self.taux_de_change_euro_dollarC = 1.45
        self.taux_de_change_dollarC_euro = 1/self.taux_de_change_euro_dollarC 
            
            
            
    """ -------------------- get LINE -------------------- """
    def getElementsOfLine(self, indice): #
        dict_ret = {}
        list_columns = self.excel_credit_etudiant.columns
        for column in list_columns:
            dict_ret[column] = self.excel_credit_etudiant[column][indice]
        return dict_ret
    
    def get_line_with_id(self, line_id):
        excel_line = self.excel_credit_etudiant["ID"][line_id]
        if excel_line != line_id:
            for row in self.excel_credit_etudiant["ID"]:
                if row != line_id:
                    excel_line += 1
                if row == line_id:
                    return self.excel_credit_etudiant.loc[excel_line]
        if excel_line == line_id:
            return self.excel_credit_etudiant.loc[excel_line]
        
    def getRowWithIndice(self, indice):
        return self.excel_credit_etudiant.loc[indice]
    
    """ -------------------- get INDICE -------------------- """
    def indiceExcelStartOfDatetime(self, day_to_find, before_or_after = "before"): #
        if type(day_to_find) != datetime.datetime:
            print("Date pas de type datetime.datetime")
            return 1
        if day_to_find > datetime.datetime.today():
            print("Vous demandez un jour dans le futur, jour demandé : ", day_to_find)
            return self.indice_end_excel
        if day_to_find < datetime.datetime(2018,8,1):
            print("Vous demandez un jour dans le passé inexistant : ", day_to_find)
            return self.indice_start_excel
        
        for i in range(self.len_excel):
            if self.valueIfDatetimeInCell("Quand", i) == day_to_find:
                return i
        if before_or_after == "before":
            day_to_find = self.dayBefore(day_to_find)
        elif before_or_after == "after":
            day_to_find = self.dayNext(day_to_find)
        return self.indiceExcelStartOfDatetime(day_to_find, before_or_after)
    
    def indiceExcelEndOfDate(self, day_to_find): #
        day_next_day_to_find = self.dayNext(day_to_find)
        if day_next_day_to_find > datetime.datetime.today(): #return end of excel
            indice_end_day_to_find = self.len_excel - 1
            return indice_end_day_to_find
        indice_next_day = self.indiceExcelStartOfDatetime(day_next_day_to_find, "after")
        indice_end_day_to_find = indice_next_day -1
        return indice_end_day_to_find
    
    def getIndiceWithID(self, id_row): #
        id_of_row = self.getRowWithIndice(id_row)["ID"]
        if id_of_row == id_row:
            return id_of_row
        else :
            for i in range(self.len_excel-1):
                if self.getRowWithIndice(i)["ID"] == id_row:
                    return i
    
    
    """ -------------------- get DATE -------------------- """
    def dateExcelOfRowIndice(self, indice): #
        indice_temp = indice
        while indice_temp > 0:
            jour_ou_case_vide = self.valueIfDatetimeInCell("Quand",indice_temp)
            if type(jour_ou_case_vide) == datetime.datetime:
                return jour_ou_case_vide
            indice_temp -= 1
        print("La date n'existe pas pour la ligne ", indice)
        return 0
    
    def getFirstDate(self): #
        return self.dateExcelOfRowIndice(2)
    
    def getLastDate(self): #
        len_shorter = self.len_excel - 1
        return self.dateExcelOfRowIndice(len_shorter)
    
    
    
    """ -------------------- get VALUE -------------------- """
    def getValueColumnRow(self, column, row): #
        return self.excel_credit_etudiant[column][row]
    
    def valeurNombreDansExcel(self, colonne, ligne):
        valeur_excel = self.excel_credit_etudiant[colonne][ligne]
        if type(valeur_excel) not in [float, int]:
            return 0
        if math.isnan(valeur_excel):
            return 0
        return valeur_excel
    
    def valeurStringDansExcel(self, colonne, index):
        valeur_excel = self.excel_credit_etudiant[colonne][index]
        if type(valeur_excel) == str:
            return valeur_excel
        return ""
    
    def valueIfDatetimeInCell(self, column, row): #
        value_excel = self.getValueColumnRow(column, row)
        value_converted = self.conversionStrDateIntoDatetime(str(value_excel))
        if type(value_converted) == datetime.datetime:
            return value_converted
        return 0

    
    """ -------------------- get DATE or  Date Transformation -------------------- """    
    def dayNext(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 1)
    
    def dayBefore(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 1)
        
    def semaineSuivante(self, date_fournie):
        return date_fournie + datetime.timedelta(days = 7)   
     
    def semainePrecedante(self, date_fournie):
        return date_fournie - datetime.timedelta(days = 7)
        
    def moisSuivant(self, date_fournie):
        return date_fournie + relativedelta(months = 1)   
     
    def moisPrecedant(self, date_fournie):
        return date_fournie - relativedelta(months = 1)  
        
        
        
    def dateAuFormatEuropeen(self, datetime_type):
        if type(datetime_type) != datetime.datetime:
            return "-"
        return str(datetime_type.day)+"/"+str(datetime_type.month)+"/"+str(datetime_type.year)
        
    def conversionStrDateIntoDatetime(self, date_a_convertir): #
        if type(date_a_convertir) != str:
            print("conversionStrDateIntoDatetime : ", date_a_convertir, "is not a string")
            return None
        if date_a_convertir == "NaT": #No value to return
            return None
        try:
            datetime_a_retourner = datetime.datetime.strptime(date_a_convertir, "%d/%m/%Y")
            return datetime_a_retourner
        except ValueError:
            try:
                datetime_a_retourner = datetime.datetime.strptime(date_a_convertir, "%Y-%m-%d")
                return datetime_a_retourner
            except ValueError:
                try:
                    datetime_a_retourner = datetime.datetime.strptime(date_a_convertir, "%Y-%m-%d %H:%M:%S")
                    return datetime_a_retourner
                except ValueError:
                    print("Error : wrong date format : ", date_a_convertir, "of type : ", type(date_a_convertir))
                    return None
    
    
    
if __name__ == "__main__":
    
    myCopy = copy_excel.CopyExcel()
    # myCopy.copyExcelToData()
    myCopy.moveToCurrentDir()
    # myCopy.removeComplexCaracters()
    print(os.getcwd())
    