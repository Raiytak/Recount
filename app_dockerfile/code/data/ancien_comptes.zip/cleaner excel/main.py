from manipulation_excel import CopyExcel, ExcelCleaner
import pandas as pd
import numpy as np


def copyAndCleanExcel():

    # --- INITIALLISATION ---
    myCopyExcel = CopyExcel()
    myCopyExcel.copyExcelToData()
    
    myExcelWrapper = ExcelCleaner()


    # Logic
    myExcelWrapper.cleanExcel()
    myExcelWrapper.end()


    # Display
    # print(dataframe.loc[:13,["ID","Quoi"]])
    
    
if __name__ == "__main__":
    copyAndCleanExcel()