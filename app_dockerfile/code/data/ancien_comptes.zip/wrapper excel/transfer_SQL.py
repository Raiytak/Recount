import pymysql
import datetime
import math
import re
import unicodedata

import json


class SQLConnector():
    def __init__(self):
        self.hostname = 'localhost'
        self.username = 'root'
        self.password = ''
        self.database = 'depenses'
        
        self.myConnection, self.cursor = self.connect()
        
    def connect(self):
        myConnection = pymysql.connect( host=self.hostname,
                                       user=self.username,
                                       passwd=self.password,
                                       db=self.database )
        return myConnection, myConnection.cursor()
    
    def  end_connection(self):
        self.myConnection.close()



class SQLWrapper(SQLConnector):
    def __init__(self):
        super().__init__()
        self.test_connection()
        
    """ -------------------- EXECUTE -------------------- """
    def execute_select(self, request_sql):
        self.execute(request_sql)
        return self.cursor.fetchall()
        
    def execute_insert(self, request_sql):
        print(request_sql)
        self.execute(request_sql)
        self.myConnection.commit()
        if self.cursor.fetchall() != ():
            return Exception
        
    def execute_delete(self, id_achat):
        request_sql = "DELETE FROM depenses_brutes WHERE depenses_brutes._id = " + str(id_achat)
        self.execute(request_sql)
        
    def execute(self, request_sql):
        response = self.cursor.execute(request_sql)
        return response
        
        
    """ -------------------- DUMP -------------------- """
    def dump_db_table(self):
        request_sql = "DELETE FROM depenses_brutes WHERE ID > -1"
        self.execute(request_sql)
        print("Delete success")
    
    def test_connection(self):
        elements_found = self.execute_select("SELECT * FROM depenses_brutes WHERE ID = -1")
        test = ((-1, datetime.date(2017, 1, 1), 65.0, 'CAD', '', '', 'Canada:Québec', 'carte', None, None, '1.0', 47),)
        if elements_found != test:
            print("Connection failed : \n", elements_found)
            id_moins_un = elements_found = self.execute_select("SELECT * FROM depenses_brutes WHERE theme = 'TEST'")
            print("Test actuel : ", id_moins_un)
            raise Exception
        print("Test connection passed")



class WrapperCsvToSqlDetails(SQLWrapper):
    def __init__(self, basicExcelAnalyser):
        self.ExcelAnalyser = basicExcelAnalyser
        super().__init__()
        
    
    def listOfRowsIndice(self, indices_excel): #
        list_row = []
        for indice in indices_excel:
            list_row.append(self.rowIndice(indice))
        return list_row
    
    def rowIndice(self, indice): #
        return self.ExcelAnalyser.getRowWithIndice(indice)

    def cleanRows(self, rows): #
        list_request_row_insertion = []
        for row in rows:
            list_col_val = self.getListColumnValue(row, "is_not_refund")
            if list_col_val != ["",""]:
                list_request_row_insertion.append(list_col_val)
        return list_request_row_insertion
    
    def getListColumnValue(self, row, refund):
        if self.isEmptyRow(row, refund) == True:
            return ["",""]
        
        list_column_value = ["",""]
        list_column = ["ID", "Quand", "Dépenses Euros", "Dépenses Dollars", 
                       "Thème", "Où", "Type", "Quoi"]
        for column_name in list_column:
            list_add = self.addElementOrPass(row, column_name)
            list_column_value[0] += list_add[0]
            list_column_value[1] += list_add[1]
        
        # to supress the last ", "
        list_column_value[0] = list_column_value[0][:-2]
        list_column_value[1] = list_column_value[1][:-2]
        return list_column_value
        
    def addElementOrPass(self, row, column): #
        element_row = row[column]
        rowID = row["ID"]
        if self.noElement(element_row):
            return ["", ""]
        if self.negativeExpense(row) == True:
            return ["", ""]
        if column == "Quand":
            if type(element_row) != datetime.datetime:
                element_row = self.getDateBeforeId(rowID)
            element_row = self.datetimeToSQLFormat(element_row)
            return ["date, ", "'"+str(element_row)+"'"+", "]
        elif column == "Dépenses Euros":
            return ["montant, devise, ", ""+str(element_row)+""+", 'EUR', "]
        elif column == "Dépenses Dollars":
            return ["montant, devise, ", ""+str(element_row)+""+", 'CAD', "]
        elif column == "Thème":
            theme, subtheme = self.getStrThemeSubTheme(element_row)
            return ["theme, soustheme", "'"+theme+"' , '"+subtheme+"' , "]
        
        elif column == "Où":
            return ["lieu, ", "'"+str(element_row)+"'"+", "]
        elif column == "Type":
            return ["methode_payement, ", "'"+str(element_row)+"'"+", "]
        elif column == "Quoi": ####### to lowercase
            list_request_sql = self.get_seller_descr_detail(element_row)
            return list_request_sql
        else :
            return [""+column+""+", ", "'"+str(element_row)+"'"+", "]
        
    def noElement(self, element_row):
        if element_row == None:
            return True
        if element_row == "Nan":
            return True
        if type(element_row)==float:
            if math.isnan(element_row) == True:
                return True
            elif element_row == 0:
                return True
        return False

    def negativeExpense(self, row):
        if (row["Dépenses Euros"]<0) or (row["Dépenses Dollars"]<0):
            return True
        
    def isEmptyRow(self, row, refund):
        if self.noElement(row["Dépenses Euros"]) == True:
            if self.noElement(row["Dépenses Dollars"]) == True:
                return True
        if refund == "is_not_refund": # REMBOURSEMENT
            if self.negativeExpense(row) == True:
                if self.negativeExpense(row) == True:
                    return True
        return False
    
    def datetimeToSQLFormat(self, datetime_elem):
        if type(datetime_elem) != datetime.datetime:
            try:
                date_elem = datetime_elem.date()
                date_str = str(date_elem)
                datetime_elem = self.ExcelAnalyser.conversionStrDateIntoDatetime(date_str)
            except Exception as e:
                print("Exception : ", str(e))
        try:
            time_sql_format = datetime_elem.strftime("%Y-%m-%d")
        except Exception as e:
            print("Exception : ", str(e), "datetime_elem : ", datetime_elem)
            time_sql_format = 0
        return time_sql_format
        
    def get_seller_descr_detail(self, element_row):
        details_low_no_acc = self.lower_accent_Formatage(element_row)
        list_split = details_low_no_acc.split(":")
        len_list = len(list_split)
        if len_list == 2:
            seller = list_split[0]
            description = list_split[1]
            list_request_sql = ["vendeur, description, ", "'"+seller+"'"+", "+"'"+description+"'"+", "]
        else:
            description = list_split[0]
            list_request_sql = ["description, ", "'"+description+"'"+", "]
        
        return list_request_sql
    
    def insertListExpensesPrepared(self, list_rows_prepared):
        start_req = "INSERT INTO depenses_brutes ("
        end_req = "VALUES ("
        for row_prepared in list_rows_prepared:
            start_request = start_req + row_prepared[0] + ") "
            end_request = end_req + row_prepared[1] + ")"
            request_sql =  start_request + end_request
            self.execute_insert(request_sql)
    
    def getDateBeforeId(self, id_date):
        indice_date = self.ExcelAnalyser.getIndiceWithID(id_date)
        date_before = self.ExcelAnalyser.dateExcelOfRowIndice(indice_date)
        return date_before
    
    def printInfo_insertDate(self, start_datetime, end_datetime):
        if type(end_datetime) == datetime.datetime:
            print("insertDate\n", "from ", self.datetimeToSQLFormat(start_datetime), "to ", self.datetimeToSQLFormat(end_datetime))
        else:
            print("insertDate\n", "date ", self.datetimeToSQLFormat(start_datetime))
    
    
    
    """ -------------------- Formatting -------------------- """
    def lower_accent_Formatage(self, str_element):
        element_lower = str_element.lower()
        element_no_accent = self.throwAccent(element_lower)
        return element_no_accent
    
    def throwAccent(self, text):
        text = str(text)
        text = unicodedata.normalize('NFD', text)
        text = text.encode('ascii', 'ignore')
        text = text.decode("utf-8")
        text.replace("'", " ")
        return str(text)
    
    def is_date_format_sql(self, date_test):
        if re.search("^[0-9]{4}-[0-9]{2}-[0-9]{2}", date_test):
            return True
        return False
    

    def getStrThemeSubTheme(self, theme_sub_theme):
        splited_tst = theme_sub_theme.split(":")
        if splited_tst == []:
            return "", ""
        theme = splited_tst[0]
        if len(splited_tst)<2:
            return theme, ""
        subtheme = splited_tst[1]
        return theme, subtheme
        """
        str_dict_theme = "{"
        for theme in dict_theme_sub_theme.keys():
            
            str_dict_theme += "'"
            str_dict_theme += str(theme)
            str_dict_theme += "'"
            
            str_dict_theme += ":"
            str_dict_theme += "["
            for stheme in dict_theme_sub_theme[theme]:
                
                str_dict_theme += "'"
                str_dict_theme += str(stheme)
                str_dict_theme += "'"
                                
                str_dict_theme += ","
            str_dict_theme = str_dict_theme[:-1]
            str_dict_theme += "]"
        
            str_dict_theme += ","
        str_dict_theme = str_dict_theme[:-1]
        str_dict_theme += "}"
        
        return str_dict_theme
        """
    
    

class WrapperCsvToSQL(WrapperCsvToSqlDetails):
    def __init__(self, basicExcelAnalyser):
        super().__init__(basicExcelAnalyser)
    
    def  end_connection(self):
        self.myConnection.close()
        
        
    """ -------------------- DUMP -------------------- """
    def dump_date(self, start_datetime, end_datetime=""):
        start_datetime = self.datetimeToSQLFormat(start_datetime)
        end_datetime = self.datetimeToSQLFormat(end_datetime)
        if (self.is_date_format_sql(start_datetime) != True) or (self.is_date_format_sql(end_datetime) != True):
            print("Wrong format of date\n", "start_datetime : ", start_datetime,
                                            "end_datetime : ", end_datetime )
            return 1
        request_sql = "DELETE FROM depenses_brutes WHERE depenses_brutes.date >= " 
        request_sql += "'"+start_datetime +"'"+ " AND depenses_brutes.date <= " + "'"+end_datetime+"'"
        self.execute(request_sql)
    
    
    
    """ -------------------- INSERT -------------------- """
    def insertExcel(self):
        start_datetime = self.ExcelAnalyser.getFirstDate()
        end_datetime = self.ExcelAnalyser.getLastDate()
        print("insertExcel :\nstart_datetime :", start_datetime, "\nend_datetime : ", end_datetime)
        self.insertDate(start_datetime, end_datetime)
    
    def insertDate(self, start_datetime, end_datetime="start_datetime"):
        if end_datetime == "start_datetime":
            end_datetime = start_datetime
        self.printInfo_insertDate(start_datetime, end_datetime)
        self.dump_date(start_datetime, end_datetime)
        rows = self.rowsDateToDate(start_datetime, end_datetime)
        rows_prepared = self.cleanRows(rows)
        self.insertListExpensesPrepared(rows_prepared)
    
    def rowsDateToDate(self, start_datetime, end_datetime): #
        indices_debut = self.ExcelAnalyser.indiceExcelStartOfDatetime(start_datetime, "after")
        indices_fin = self.ExcelAnalyser.indiceExcelEndOfDate(end_datetime)
        indices_excel = range(indices_debut, indices_fin)
        list_rows = self.listOfRowsIndice(indices_excel)
        return list_rows
    
