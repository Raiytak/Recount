from basic_analyser import BasicExcelAnalyser
from transfer_SQL import WrapperCsvToSQL
import datetime

basicExcelAnalyser = BasicExcelAnalyser()
myTransfert = WrapperCsvToSQL(basicExcelAnalyser)

start_datetime = datetime.datetime(2019,8,1)
end_datetime = datetime.datetime.now()

# myTransfert.insertDate(start_datetime, end_datetime)
myTransfert.insertExcel()
# myTransfert.dump_db_table()


myTransfert.end_connection()