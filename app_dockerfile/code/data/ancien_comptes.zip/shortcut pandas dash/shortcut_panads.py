import numpy as np
import pandas as pd
import datetime





class ExcelWrapper():
    def __init__(self):
        self._path = self.getPathToExcel()
        self._pdExcel = self.getCurrentExcelReader()
        
        
    def getPathToExcel(self):
        _path = r"C:\Users\User1\Desktop\Projets\Comptes\data"
        name = "credit_etudiant.xlsx"
        return _path + "/" + name
    
    def getCurrentExcelReader(self):
        xl_file = pd.ExcelFile(self._path)
        dfs = {sheet_name: xl_file.parse(sheet_name) 
                for sheet_name in xl_file.sheet_names}
        return dfs["Feuil1"]
    
    def getCurrentExcel(self):
        return self._pdExcel
    
    def addDateEverywhere(self):
        last_date = np.datetime64("2019-07-01")
        
        for i in range(len(self.getCurrentExcel())):
            current_date = self.getCurrentExcel().loc[i,"Quand"]
            
            if pd.isnull(current_date):
                self.getCurrentExcel().at[i,"Quand"] = last_date
            else:
                last_date = current_date
    
    def removeSummationLines(self):
        self_excel = self.getCurrentExcel()
        for i in range(len(self_excel)):
            current_line = self_excel.loc[i]
            
            if pd.isnull(current_line["Dépenses Euros"]) and pd.isnull(current_line["Dépenses Dollars"]):
                # print(current_line)
                self_excel = self_excel.drop(i)
                
        self._pdExcel = self_excel
        
    def addSummarizeExpensesColumn(self):
        self_excel = self.getCurrentExcel()
        list_expenses = self.getListExpenses()
        # self_excel.insert(loc=0, column="Dépenses", value=list_expenses)
        # self_excel = self_excel.drop("Dépenses Euros")
        # self_excel = self_excel.drop("Dépenses Dollars")
        # print(self_excel)
        
    def getListExpenses(self):
        list_expensesED = self.getCurrentExcel().loc[:,["Dépenses Euros", "Dépenses Dollars"]]
        list_expenses = [self.getExpenseInEuros(row) for row in list_expensesED]
        print(list_expenses)
        return list_expenses
    
    def getExpenseInEuros(self, row):
        print(row)
        expenseE, expenseD = self.getExpenseValue(row)
        return expenseE + (expenseD/1.5)
    
    def getExpenseValue(self, row): #REPLACE WITH .add(..., fill_value=0)
        expenseE = row["Dépenses Euros"]
        expenseD = row["Dépenses Dollars"]
        if pd.isnull(expenseE):
            expenseE = 0
        if pd.isnull(expenseD):
            expenseD = 0
        return expenseE, expenseD
        
        

def setNanToZero(excel_part):
    for i in range(len(excel_part)):
        cell = excel_part.loc[i]        
        
        if pd.isnull(cell):
            cell = 0
        excel_part.loc[i] = cell
    return excel_part
    

def convertStrIntoThemeSubThemes(str_to_convert):
    dict_tSt = {}
    list_themes = str_to_convert.split(";")
    for tSt_theme in list_themes:
        list_tStheme = tSt_theme.split(":")
        theme = list_tStheme.pop(0)
        subThemes = []
        if list_tStheme != []:
            subThemes = list_tStheme[0].split("+")
        dict_tSt[theme] = subThemes
    return dict_tSt
        

    
if __name__ == "__main__":
    myEW = ExcelWrapper()
    myExcel = myEW.getCurrentExcel()
    myExcel = myExcel.drop(columns=["Sommes E", "Sommes D", "Excédentaires E", "Excédentaires D", "Somme euro", "Somme dollar"])
    
    print("avant")    

    
    myEW.addDateEverywhere()
    # myEW.addSummarizeExpensesColumn()
    myExcel["Dépenses Euros"] = setNanToZero(myExcel["Dépenses Euros"])
    myExcel["Dépenses Dollars"] = setNanToZero(myExcel["Dépenses Dollars"])
    myEW.removeSummationLines()    
    myExcel["Dépenses"] = myExcel["Dépenses Euros"] + myExcel["Dépenses Dollars"]
    myExcel = myExcel.drop(columns=["Dépenses Euros", "Dépenses Dollars"])
    
    
    print(myExcel.head())
    str_to_convert = myExcel.loc[1,"Thème"]
    result = convertStrIntoThemeSubThemes(str_to_convert)
    print(result)


