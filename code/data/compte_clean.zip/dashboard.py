import dash
import dash_html_components as html
import dash_core_components as dcc

import datetime


import wrapper_dash.prepare_dashboard as prepare_dashboard
import communication_db

import wrapper_dash.conversion_dataframe_to_dash_graph as conversion_dataframe_to_dash_graph



class DashboardA():
    def __init__(self):
        self.emptyDashboard = prepare_dashboard.EmptyDashboard()
        self.app = dash.Dash()
        
        self.dateToDataframe = communication_db.DateToDataframe()
        self.dataframeToLD = conversion_dataframe_to_dash_graph.DataframeToListOfDicts()
        self.dataframeToGraph = conversion_dataframe_to_dash_graph.DataframeToGraph()
    
    def callback(self):
        @self.app.callback(
            [dash.dependencies.Output("scatter-output", "figure"),
            dash.dependencies.Output("pie-output", "figure"),
            dash.dependencies.Output("mean-output", "figure"),
            dash.dependencies.Output("food-output", "figure")],
            [dash.dependencies.Input("input-date", 'date'),
            dash.dependencies.Input("input-radio", 'value')])
        def update_graph(selected_date_str, selected_periode):        
            start_date = getDate(selected_date_str)
            
            dataframe = self.dateToDataframe.getDataframeFromDate(start_date, selected_periode)
            list_dataframes = self.dateToDataframe.getListDataframeByWeekFromDate(start_date, selected_periode)
            
            scatter_graph = self.dataframeToGraph.convertDataframeToGraph(dataframe, "all-scatter")
            pie_graph = self.dataframeToGraph.convertDataframeToGraph(dataframe, "theme-pie")
            mean_graph = self.dataframeToGraph.convertDataframeToGraph(list_dataframes, "mean-bar")
            food_graph = self.dataframeToGraph.convertDataframeToGraph(list_dataframes, "food-bar")
            
            return scatter_graph, pie_graph, mean_graph, food_graph

    
    def prepareDashboard(self):
        self.app.layout = self.emptyDashboard.getEmptyDashboardA()
        self.callback()
            
    def run(self):
        self.app.run_server(debug=True)
        
        
        
        
    def testGraph(self, graph):
        # all-scatter, theme-pie, mean-bar, food-bar
        self.app.layout = dcc.Graph(figure=graph)
        self.app.run_server(debug=True)
        
    
    

def getDate(my_date):
    try:
        formated_date = datetime.datetime.strptime(my_date, "%Y-%m-%dT%H:%M:%S.%f")
        return formated_date
    except ValueError:
        pass
    
    try:
        formated_date = datetime.datetime.strptime(my_date, "%Y-%m-%d")
        return formated_date
    except ValueError:
        pass
    
    raise Exception