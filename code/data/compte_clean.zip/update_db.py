import wrapper_excel.access_copy_excel as access_copy_excel

import wrapper_sql.wrapper_sql as wrapper_sql
import wrapper_sql.dataframe_to_request_sql as dataframe_to_request_sql
import wrapper_sql.raw_to_other_table as raw_to_other_table
import wrapper_sql.repay_repayments as repay_repayments



myCleaner = access_copy_excel.CleanerExcel()

convertDfToReq = dataframe_to_request_sql.DataframeToSql()
convertRespToDf = wrapper_sql.ResponseSqlToDataframe()
convertRespToList = wrapper_sql.ResponseSqlToList()

rawTableWrapper = wrapper_sql.WrapperOfTable("depenses_brutes")
tripTableWrapper = wrapper_sql.WrapperOfTable("depenses_voyages")
repTableWrapper = wrapper_sql.WrapperOfTable("remboursements")
cleanTableWrapper = wrapper_sql.WrapperOfTable("depenses_propres")

rawToRepayement = raw_to_other_table.RawToRepayement(rawTableWrapper, repTableWrapper)
rawToTrip = raw_to_other_table.RawToTrip(rawTableWrapper, tripTableWrapper)
rawToClean = raw_to_other_table.RawToClean(rawTableWrapper, cleanTableWrapper)
tripToClean = raw_to_other_table.TripToClean(tripTableWrapper, cleanTableWrapper)

repayRep = repay_repayments.RepayPepayements(rawTableWrapper, repTableWrapper)



def updateRawTable():
    print("--- Update 'depenses_brutes' Table ---")
    myCleaner.updateExcel()
    dataframe, equivalent_columns = myCleaner.getDataframeAndEqCol()
    list_req = convertDfToReq.translateDataframeToRequestSql(dataframe, equivalent_columns)
    rawTableWrapper.dumpTable()
    for request in list_req:
        rawTableWrapper.insert(request)



def updateRepayements():
    print("--- Update 'remboursement' Table ---")
    response = rawToRepayement.selectRepayementRows()
    dataframe = convertRespToDf.translateResponseSqlToDataframe(response, rawTableWrapper)
    equivalent_columns = rawToRepayement.getEquivalentColumns()
    requests = convertDfToReq.translateDataframeToRequestSql(dataframe, equivalent_columns, rawToRepayement)
    rawToRepayement.insertAllReqs(requests)

def deleteRepayementsFromRaw():
    print("--- Delete 'remboursement' in 'depenses_brutes' ---")
    response = rawToRepayement.selectRepayementIds()
    list_resp = convertRespToList.translateResponseSqlToList(response)
    rawToRepayement.deleteRepayementRowsInRaw(list_resp)

def repayRepayements():
    print("--- Repay 'remboursement' in 'depenses_brutes' ---")
    response_rep = repayRep.selectRepayementRows()
    dataframe_rep = convertRespToDf.translateResponseSqlToDataframe(response_rep, repTableWrapper)
    
    list_ids_pay_orig = repayRep.convertDataframeToListIdsPayOrig(dataframe_rep)
    response_raw = repayRep.selectRowsOfRawWhereIds(list_ids_pay_orig)
    repayRep.deleteRowsOfRawWhereIds(list_ids_pay_orig)
    
    dataframe_raw = convertRespToDf.translateResponseSqlToDataframe(response_raw, rawTableWrapper)
    dataframe_cleaned = repayRep.addDfRawAndDfRepayement(dataframe_raw, dataframe_rep)
    
    equivalent_columns = convertRespToDf.getEquivalentColumns(rawTableWrapper)
    requests_cleaned_rows = convertDfToReq.translateDataframeToRequestSql(dataframe_cleaned, equivalent_columns)
    repayRep.insertCleanedRowsReqs(requests_cleaned_rows)



def updateTrips():
    print("--- Update 'depenses_voyages' ---")
    response = rawToTrip.selectTripRows()
    dataframe = convertRespToDf.translateResponseSqlToDataframe(response, rawTableWrapper)
    equivalent_columns = rawToTrip.getEquivalentColumns()
    requests = convertDfToReq.translateDataframeToRequestSql(dataframe, equivalent_columns, rawToTrip)
    rawToTrip.insertAllReqs(requests)

def deleteTripsFromRaw():
    print("--- Delete 'depenses_voyages' in 'depenses_brutes' ---")
    response = rawToTrip.selectTripIds()
    list_resp = convertRespToList.translateResponseSqlToList(response)
    rawToTrip.deleteTripRowsInRaw(list_resp)



def updateClean():
    print("--- Update 'depenses_propres' ---")
    response = rawToClean.selectAllRemainingRowsInRaw()
    dataframe = convertRespToDf.translateResponseSqlToDataframe(response, rawTableWrapper)
    equivalent_columns = rawToClean.getEquivalentColumns()
    requests = convertDfToReq.translateDataframeToRequestSql(dataframe, equivalent_columns, rawToTrip)
    rawToClean.insertAllReqs(requests)
    
    print("--- Adding the trip expenses ---")
    response = tripToClean.selectAllRemainingRowsInTrip()
    dataframe = convertRespToDf.translateResponseSqlToDataframe(response, tripTableWrapper)
    equivalent_columns = tripToClean.getEquivalentColumns()
    requests = convertDfToReq.translateDataframeToRequestSql(dataframe, equivalent_columns, tripToClean)
    tripToClean.insertAllReqsWithoutDump(requests)



# main
def updateAll():
    updateRawTable()

    updateRepayements()
    deleteRepayementsFromRaw()
    repayRepayements()

    updateTrips()
    deleteTripsFromRaw()

    updateClean()