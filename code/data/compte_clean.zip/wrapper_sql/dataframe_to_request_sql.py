import datetime
import unidecode

import numpy as np
import pandas as pd



class DataframeToSql():
    def translateDataframeToRequestSql(self, dataframe, equivalent_columns, tableA_to_tableB=None):
        dict_of_list_list = self.convertDataframeColumnsToDictOfListList(dataframe, tableA_to_tableB)
        list_requests_sql = self.convertDictListListToRequestSql(dict_of_list_list, equivalent_columns)
        return list_requests_sql
    
        
    def convertDataframeColumnsToDictOfListList(self, dataframe, tableA_to_tableB):
        dict_by_columns = {"len":len(dataframe)}
        list_columns = dataframe.columns
        for col in list_columns:
            dict_by_columns[col] = self._convertColumnValue(dataframe[col], col)
        return dict_by_columns
    
    def _convertColumnValue(self, dataframe_col, column):
        conversionDF = ConversionDataframe()
        if column == "Quand":
            list_list_returned = conversionDF.convertDFDateToListList(dataframe_col)
        elif column == "Thème":
            list_list_returned = conversionDF.convertDFThemeToListList(dataframe_col)
        elif column == "Quoi":
            list_list_returned = conversionDF.convertDFDescriptionToListList(dataframe_col)
        else:
            list_list_returned = [list(dataframe_col.apply(str))]
        return list_list_returned

    def convertDictListListToRequestSql(self, dict_list_list, dict_equivalent_columns):
        equivalent_columns = dict_equivalent_columns
        start_requests = ["INSERT INTO & ("]*dict_list_list["len"]
        end_requests = ["VALUES ("]*dict_list_list["len"]
        
        for column_excel in equivalent_columns.keys():
            columns_sql = equivalent_columns[column_excel]
            if column_excel == "ID": #Goal is to avoid a coma at the start of the request (try without the if and look at the requests to understand)
                values = dict_list_list[column_excel][0]
                dict_list_list_bool = [False if (values[i]==str(np.nan) or values[i]=="None") else True for i in range(len(values))]
                start_requests = self._concatenateRequestsAndValueWithoutComa(start_requests, columns_sql[0], dict_list_list_bool)
                end_requests = self._concatenateRequestsAndListValuesWithoutComa(end_requests, dict_list_list[column_excel][0], dict_list_list_bool)
            else:
                for i in range(len(columns_sql)):
                    values = dict_list_list[column_excel][i]
                    dict_list_list_bool = [False if (values[i]==str(np.nan) or values[i]=="None") else True for i in range(len(values))]
                    start_requests = self._concatenateRequestsAndValue(start_requests, columns_sql[i], dict_list_list_bool)
                    end_requests = self._concatenateRequestsAndListValues(end_requests, dict_list_list[column_excel][i],dict_list_list_bool)
                
        start_requests = self.closeRequest(start_requests)
        end_requests = self.closeRequest(end_requests)
            
        list_requests = self._concatenateRequestsAndList(start_requests, end_requests)
            
        return list_requests
            
    
    def _concatenateRequestsAndList(self, requests, values):
        return [requests[i]+" "+values[i] for i in range(len(requests))]
                
                
    def _concatenateRequestsAndValue(self, requests, column_sql, dict_list_list_bool):
        return [requests[i]+", "+column_sql if dict_list_list_bool[i] else requests[i] for i in range(len(requests))]
    
    def _concatenateRequestsAndListValues(self, requests, values, dict_list_list_bool):
        return [requests[i]+", '"+values[i]+"'" if dict_list_list_bool[i] else requests[i] for i in range(len(requests))]
    
                
    def _concatenateRequestsAndValueWithoutComa(self, requests, column_sql, dict_list_list_bool):
        return [requests[i]+column_sql if dict_list_list_bool[i] else requests[i] for i in range(len(requests))]
    
    def _concatenateRequestsAndListValuesWithoutComa(self, requests, values, dict_list_list_bool):
        return [requests[i]+"'"+values[i]+"'" if dict_list_list_bool[i] else requests[i] for i in range(len(requests))]
    
    
    def closeRequest(self, requests):
        return [requests[i] + ")" for i in range(len(requests))]





class ConversionDataframe():
    def convertDFDateToListList(self, dataframe_col):
        def convertDatetimeToSQLFormat(datetime_elem):
            time_sql_format = datetime_elem.strftime("%Y-%m-%d")
            return time_sql_format
        dataframe_theme = dataframe_col.apply(convertDatetimeToSQLFormat)
        list_list_returned = [list(dataframe_theme.apply(str))]
        return list_list_returned
    
    def convertDFThemeToListList(self, dataframe_col):
        def convertIntoTheme(theme_subtheme):
            theme_subtheme = str(theme_subtheme)
            list_tst = theme_subtheme.split(":")
            if list_tst != []:
                return list_tst[0]
        def convertIntoSubtheme(theme_subtheme):
            theme_subtheme = str(theme_subtheme)
            list_tst = theme_subtheme.split(":")
            if len(list_tst) > 1:
                return list_tst[1]
            return str(np.nan)
        dataframe_theme = dataframe_col.apply(convertIntoTheme)
        dataframe_subtheme = dataframe_col.apply(convertIntoSubtheme)
        list_list_returned = [list(dataframe_theme.apply(str)), list(dataframe_subtheme.apply(str))]
        return list_list_returned
    
    def convertDFDescriptionToListList(self, dataframe_col):
        def isOnlyEnterprise(raw_description):
            splited_descr = raw_description.split()
            if len(splited_descr) > 1:
                return False
            resplited_descr = splited_descr[0].split(":")
            if len(resplited_descr) > 1:
                return False
            return True
        def convertIntoEnterprise(raw_description):
            if isOnlyEnterprise(raw_description):
                return raw_description
            list_descr = raw_description.split(":")
            if len(list_descr) > 1:
                entreprise = list_descr[0]
                if entreprise == "":
                    return str(np.nan)
                return list_descr[0]
            return str(np.nan)
        def convertIntoDescription(raw_description):
            if isOnlyEnterprise(raw_description):
                return str(np.nan)
            list_descr = raw_description.split(":")
            if len(list_descr) > 1:
                return list_descr[1]
            return list_descr[0]
        dataframe_entreprise = dataframe_col.apply(convertIntoEnterprise)
        dataframe_description = dataframe_col.apply(convertIntoDescription)
        
        list_list_returned = [list(dataframe_entreprise.apply(str)), list(dataframe_description.apply(str))]
        return list_list_returned

    
    