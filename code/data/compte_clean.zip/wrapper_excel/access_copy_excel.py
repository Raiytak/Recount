# -*- coding: utf-8 -*-

import os
import sys
from shutil import copyfile
import unidecode

import numpy as np
import pandas as pd



class ExcelPaths():
    def __init__(self):
        self.excel = self.getProjectExcelPath()
        self._real_excel = self.getRealExcelPath()
    
    def getProjectExcelPath(self):
        project_excelexcel = self.getDataPath() + "/comptes.xlsx"
        return project_excelexcel
        
    def getRealExcelPath(self):
        path_excel = r"C:\Users\User1\Desktop\Le Dossier\Comptes\credit_etudiant.xlsx"
        return path_excel
    
    def getDataPath(self):
        path_data = r"C:\Users\User1\Desktop\Projets\Comptes_clean\data"
        return path_data

    def popEnd(self, name_directory):
        size = len(name_directory)
        for i in range(size-1,0,-1):
            if name_directory[i] == "/":
                break
        return name_directory[0:i]



class ExcelToDataframe(ExcelPaths):
    def __init__(self):
        super().__init__()
        
    def getCurrentExcelReader(self):
        xl_file = pd.ExcelFile(self.excel)
        dfs = {sheet_name: xl_file.parse(sheet_name) 
                for sheet_name in xl_file.sheet_names}
        return dfs["Feuil1"]
    
    def getDataframe(self):
        return self._pdExcel
    
    def getDataframeAndEqCol(self):
        equivalent_columns = {"ID":["ID"], "Quand":["date"], "Dépenses":["montant"],
                            "Thème":["theme", "soustheme"], "Voyage":["voyage"], 
                            "Type":["methode_payement"], "Quoi":["entreprise", "description"]}
        return self._pdExcel, equivalent_columns
    
    def updatDataframe(self):
        self._pdExcel = self.getCurrentExcelReader()



class CleanerDataframe(ExcelToDataframe):
    def __init__(self):
        super().__init__()
    
    def addDateEverywhere(self):
        last_date = np.datetime64("2019-07-01")
        for i in range(len(self.getDataframe())):
            current_date = self.getDataframe().loc[i,"Quand"]
            
            if pd.isnull(current_date):
                self.getDataframe().at[i,"Quand"] = last_date
            else:
                last_date = current_date
    
    def removeSummationLines(self):
        self_excel = self.getDataframe()
        for i in range(len(self_excel)):
            current_line = self_excel.loc[i]
            if pd.isnull(current_line["Dépenses Euros"]) and pd.isnull(current_line["Dépenses Dollars"]):
                self_excel = self_excel.drop(i)
        self._pdExcel = self_excel
    
    def addSummarizedExpensesColumn(self):
        self_excel = self.getDataframe()
        list_expenses = self.getListExpenses()
        self_excel.insert(loc=0, column="Dépenses", value=list_expenses)
        self._pdExcel = self_excel

    def getListExpenses(self):
        df_expenses = self.getDataframe().loc[:,["Dépenses Euros", "Dépenses Dollars"]]
        df_expenses = df_expenses.fillna(0) #Fill the nan values with 0
        df_expenses = [self.convertExpenseInEuros(row) for index, row in df_expenses.iterrows()]
        return df_expenses
    
    def convertExpenseInEuros(self, row):
        expenseE = row["Dépenses Euros"]
        expenseD = row["Dépenses Dollars"]
        return np.around(expenseE + (expenseD/1.5), 2) #Limit the number of digits to 2
    
    def removeRawExpensesColumns(self):
        self_excel = self.getDataframe()
        self_excel = self_excel.drop(columns=["Dépenses Euros", "Dépenses Dollars"])
        self._pdExcel = self_excel
    
    def removeUselessColumns(self):
        self_excel = self.getDataframe()
        list_columns = ["Somme euro", "Somme dollar", "Sommes E", "Sommes D", "Excédentaires E", "Excédentaires D"]
        self_excel = self_excel.drop(columns=list_columns)
        self._pdExcel = self_excel
        
    
    def normalizeDescription(self):
        self_excel = self.getDataframe()
        self_excel["Quoi"] = self_excel["Quoi"].apply(self.removeAccentAndApostropheInStr)
        self._pdExcel = self_excel
        
        
    def splitAnCleanTheme(self):
        self_excel = self.getDataframe()
        
        self._pdExcel = self_excel
        
        
    def splitAnCleanDescription(self):
        self_excel = self.getDataframe()
        
        self._pdExcel = self_excel
    

    def removeAccentAndApostropheInStr(self, text):
        text = unidecode.unidecode(text) #Remove accents
        #Have to remove the apostrophes for the pymysql that doesn't support it
        text = text.replace("'", " ") 
        text = text.lower()
        return text
    
    

class CleanerExcel(CleanerDataframe):
    def __init__(self):
        super().__init__()
        self.copyExcelToData()
        self.updatDataframe()
        
    def updateExcel(self):
        self.copyExcelToData()
        self.removeSummationLines()
        self.addDateEverywhere() 
        self.addSummarizedExpensesColumn()
        self.removeRawExpensesColumns()
        self.removeUselessColumns()
        self.normalizeDescription()
        self.splitAnCleanTheme()
        self.splitAnCleanDescription()
        self._pdExcel.to_excel(self.excel)

    def copyExcelToData(self):
        copyfile(self._real_excel, self.excel)  




if __name__ == "__main__":
    myCleaner = CleanerExcel()
    myCleaner.updateExcel()
    myExcel = myCleaner.getDataframe()
    print(myExcel)
