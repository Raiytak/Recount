import transfer_SQL
import basic_analyser
import datetime


class TestFunctions():
    def __init__(self):
        self.basicExcelAnalyser = basic_analyser.BasicExcelAnalyser()
        self.csvTOsql = transfer_SQL.csvTOsql(self.basicExcelAnalyser)
    
    
    def test_basicExcelAnalyser(self):
        self.test_conversionStrDateIntoDatetime()
        self.test_valueIfDatetimeInCell()
        self.test_indiceExcelStartOfDate()
        self.test_indiceExcelEndOfDate()
        self.test_dateExcelOfRowIndice()
        self.test_getIndiceWithID()
    
    def test_csvTOsql(self):
        self.test_rowsOfDate()
        self.test_cleanRows()
    
    
    """ -------------------- basicExcelAnalyser part -------------------- """
    def test_conversionStrDateIntoDatetime(self):
        date_to_convert = datetime.date(2019,2,17)
        datetime_equivalent = datetime.datetime(2019,2,17)
        date_str = str(date_to_convert)
        date_str_converted = self.basicExcelAnalyser.conversionStrDateIntoDatetime(date_str)
        if datetime_equivalent == date_str_converted:
            return "passed"
        return "failed"
    
    def test_valueIfDatetimeInCell(self):
        value_found = self.basicExcelAnalyser.valueIfDatetimeInCell("Quand",3)
        if type(value_found) == datetime.datetime:
            if value_found == datetime.datetime(2019,8,4):
                return "passed"
        return "failed"    
    
    def test_indiceExcelStartOfDate(self): #self, date_to_find = 0, before_or_after = "before"
        date_to_find = datetime.datetime(2019,8,1)
        date_should_found = date_to_find
        before_or_after = "before"
        indice_found = self.basicExcelAnalyser.indiceExcelStartOfDatetime(date_to_find, before_or_after) #
        value_date = self.basicExcelAnalyser.valueIfDatetimeInCell("Quand", indice_found)
        if value_date != date_should_found:
            return "failed"
        
        date_to_find = datetime.datetime(2019,9,4)
        date_should_found = datetime.datetime(2019,9,5)
        before_or_after = "after"
        indice_found = self.basicExcelAnalyser.indiceExcelStartOfDatetime(date_to_find, before_or_after) #
        value_date = self.basicExcelAnalyser.valueIfDatetimeInCell("Quand", indice_found)
        if value_date == date_should_found:
            return "passed"
        return "failed"
        
    def test_indiceExcelEndOfDate(self):
        date_to_find = datetime.datetime(2019,12,6)
        indice_found = self.basicExcelAnalyser.indiceExcelEndOfDate(date_to_find)
        row_found = self.basicExcelAnalyser.getElementsOfLine(indice_found-1)
        if row_found["Dépenses Dollars"] == 124.49: #id 255
            return "passed"
        return "failed"
    
    def test_dateExcelOfRowIndice(self):
        indice = 1
        date_should_found = datetime.datetime(2019,8,1)
        date_found = self.basicExcelAnalyser.dateExcelOfRowIndice(indice)
        if date_found == date_should_found:
            return "passed"
        return "failed"
    
    def test_getIndiceWithID(self):
        id_test = 128
        indice_found = self.basicExcelAnalyser.getIndiceWithID(id_test)
        if self.basicExcelAnalyser.getElementsOfLine(indice_found)["ID"] == id_test:
            return "passed"
        return "failed"
    
    
    
    
    """ -------------------- csvTOsql part -------------------- """
    def test_rowsOfDate(self):
        date_start = datetime.datetime(2019,12,12)
        date_stop = datetime.datetime(2019,12,15)
        rows_date = self.csvTOsql.rowsDToD(date_start, date_stop)
        if rows_date[2]["Dépenses Dollars"] == 20:
            return "passed"
        return "failed"
    
    def test_cleanRows(self):
        rows = [self.basicExcelAnalyser.getRowWithIndice(50)]
        cleaned_rows = self.csvTOsql.cleanRows(rows)
        row_should_be = [['ID, date, montant, devise, description', "'50', '2019-08-29', 120.6, 'CAD', 'lpu'"]]
        if cleaned_rows == row_should_be:
            return "passed"
        return "failed"
        
    
myTest = TestFunctions()
myTest.test_basicExcelAnalyser()
myTest.test_csvTOsql()
