import update_db

import dashboard
import communication_db


# --- UPDATING DATABASE ---
update_db.updateAll()   


# --- UPDATING DASHBOARD ---
myDashboard = dashboard.DashboardA()

def runDashboar():
    myDashboard.prepareDashboard()
    myDashboard.run()
    
    
    

# import wrapper_dash.conversion_dataframe_to_dash_graph as conversion_dataframe_to_dash_graph

# dateToDataframe = communication_db.DateToDataframe()
# dataframeToLD = conversion_dataframe_to_dash_graph.DataframeToListOfDicts()
# dataframeToGraph = conversion_dataframe_to_dash_graph.DataframeToGraph()

# def translateDateToDataframe(start_date, end_date):
#     # dataframe = dateToDataframe.getDataframeFromDate(start_date, "semestre")
#     # graph = dataframeToGraph.convertDataframeToGraph(dataframe, "theme-pie")
#     # myDashboard.testGraph(graph)
    
#     list_dataframe = dateToDataframe.getListDataframeByWeekFromDate(start_date, "semestre")
#     graph = dataframeToGraph.convertDataframeToGraph(list_dataframe, "food-bar")
#     myDashboard.testGraph(graph)




# --- MAIN PART ---

runDashboar()

