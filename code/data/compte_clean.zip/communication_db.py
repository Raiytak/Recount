import datetime
from dateutil.relativedelta import relativedelta

import wrapper_sql.wrapper_sql as wrapper_sql



class DateToDataframe:
    def __init__(self):
        self.bd_sql = wrapper_sql.WrapperOfTable("depenses_propres")
        self.translator = wrapper_sql.ResponseSqlToDataframe()
    
    def getListDataframeByWeekFromDate(self, start_date, periode):
        list_dataframe = []
        current_date = start_date
        end_date = self._convertPeriodeToDate(start_date, periode)
        while current_date < end_date:
            dataframe = self.getDataframeFromDate(current_date, "week")
            dataframe["date_week"] = current_date.strftime("%Y-%m-%d")
            if dataframe.empty == False:
                list_dataframe.append(dataframe)
            current_date = self._addWeek(current_date)
        return list_dataframe
    
    def getDataframeFromDate(self, start_date, periode):
        end_date = self._convertPeriodeToDate(start_date, periode)
        dataframe = self.convertDateToDataframe(start_date, end_date)
        return dataframe
        
    
    def convertDateToDataframe(self, start_date, end_date):
        request = self.convertDateToRequestSQL(start_date, end_date)
        reponse = self.bd_sql.select(request)
        dataframe = self.translateSqlToDataframe(reponse)
        return dataframe
        
        
    def convertDateToRequestSQL(self, start_date, end_date):
        start_req = "SELECT * FROM & WHERE date >= "
        mid_req = self._getDatetimeInGoodShape(start_date)+" AND date < "
        end_req = self._getDatetimeInGoodShape(end_date)
        request = start_req + mid_req + end_req
        return request
    
    def _getDatetimeInGoodShape(self, my_datetime):
        return "'"+my_datetime.strftime("%Y-%m-%d")+"'"

    def translateSqlToDataframe(self, response):
        dataframe = self.translator.translateResponseSqlToDataframe(response, self.bd_sql)
        return dataframe
    
    
    def _convertPeriodeToDate(self, start_date, periode):
        end_date = start_date        
        if periode == "week":
            end_date += relativedelta(weeks=1)
        elif periode == "month":
            end_date += relativedelta(months=1)
        elif periode == "semestre":
            end_date += relativedelta(months=4)
        else:
            print("Period not accepted : \nonly 'week', 'month' and 'semestre' are authoriezd")
            raise Exception
        return end_date
    
    def _addWeek(self, current_date):
        current_date = current_date + relativedelta(weeks=1)
        return current_date